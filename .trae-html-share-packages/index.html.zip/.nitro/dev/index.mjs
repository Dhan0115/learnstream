import process from 'node:process';globalThis._importMeta_={url:import.meta.url,env:process.env};import { tmpdir } from 'node:os';
import destr from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/destr@2.0.5/node_modules/destr/dist/index.mjs';
import { defineEventHandler, handleCacheHeaders, splitCookiesString, createEvent, fetchWithEvent, isEvent, eventHandler, setHeaders, createError, sendRedirect, proxyRequest, getRequestURL, getRequestHeader, getResponseHeader, getRequestHeaders, setResponseHeaders, setResponseStatus, send, removeResponseHeader, appendResponseHeader, setResponseHeader, createApp, createRouter as createRouter$1, toNodeListener, lazyEventHandler, getRouterParam, readBody, getQuery as getQuery$1, setCookie, getCookie, deleteCookie, getRequestIP, readMultipartFormData, sendStream } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/h3@1.15.11/node_modules/h3/dist/index.mjs';
import { createHooks } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/hookable@5.5.3/node_modules/hookable/dist/index.mjs';
import { createFetch, Headers as Headers$1 } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/ofetch@1.5.1/node_modules/ofetch/dist/node.mjs';
import { fetchNodeRequestHandler, callNodeRequestHandler } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/node-mock-http@1.0.5/node_modules/node-mock-http/dist/index.mjs';
import { parseURL, withQuery, getQuery, withoutBase, joinURL, decodePath, withLeadingSlash, withoutTrailingSlash } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/ufo@1.6.4/node_modules/ufo/dist/index.mjs';
import { createStorage, prefixStorage } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/unstorage@1.17.6_db0@0.3.4_ioredis@5.11.1_supports-color@10.2.2_/node_modules/unstorage/dist/index.mjs';
import unstorage_47drivers_47fs from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/unstorage@1.17.6_db0@0.3.4_ioredis@5.11.1_supports-color@10.2.2_/node_modules/unstorage/drivers/fs.mjs';
import { digest } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/ohash@2.0.12/node_modules/ohash/dist/index.mjs';
import { klona } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/klona@2.0.6/node_modules/klona/dist/index.mjs';
import defu, { defuFn } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/defu@6.1.7/node_modules/defu/dist/defu.mjs';
import { snakeCase } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/scule@1.3.0/node_modules/scule/dist/index.mjs';
import { getContext } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/unctx@2.5.0/node_modules/unctx/dist/index.mjs';
import { toRouteMatcher, createRouter } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/radix3@1.1.2/node_modules/radix3/dist/index.mjs';
import { readFile as readFile$1, mkdir, writeFile, rm, stat } from 'node:fs/promises';
import { resolve, dirname, join, extname, sep } from 'node:path';
import consola from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/consola@3.4.2/node_modules/consola/dist/index.mjs';
import { ErrorParser } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/youch-core@0.3.3/node_modules/youch-core/build/index.js';
import { Youch } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/youch@4.1.1/node_modules/youch/build/index.js';
import { SourceMapConsumer } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/source-map@0.7.6/node_modules/source-map/source-map.js';
import { promises, createReadStream } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname as dirname$1, resolve as resolve$1 } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/pathe@2.0.3/node_modules/pathe/dist/index.mjs';
import { Server } from 'node:http';
import nodeCrypto, { timingSafeEqual, randomBytes, scrypt, createHash, randomUUID } from 'node:crypto';
import { parentPort, threadId } from 'node:worker_threads';
import { PrismaClient } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/@prisma+client@6.19.3_prisma@6.19.3_magicast@0.5.5_typescript@5.6.3__typescript@5.6.3/node_modules/@prisma/client/default.js';
import { promisify } from 'node:util';
import { z } from 'file:///Users/dhan/Applications/LearnStream/node_modules/.pnpm/zod@4.6.7/node_modules/zod/index.js';

const serverAssets = [{"baseName":"server","dir":"/Users/dhan/Applications/LearnStream/server/assets"}];

const assets$1 = createStorage();

for (const asset of serverAssets) {
  assets$1.mount(asset.baseName, unstorage_47drivers_47fs({ base: asset.dir, ignore: (asset?.ignore || []) }));
}

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('root', unstorage_47drivers_47fs({"driver":"fs","readOnly":true,"base":"/Users/dhan/Applications/LearnStream"}));
storage.mount('src', unstorage_47drivers_47fs({"driver":"fs","readOnly":true,"base":"/Users/dhan/Applications/LearnStream/server"}));
storage.mount('build', unstorage_47drivers_47fs({"driver":"fs","readOnly":false,"base":"/Users/dhan/Applications/LearnStream/.nitro"}));
storage.mount('cache', unstorage_47drivers_47fs({"driver":"fs","readOnly":false,"base":"/Users/dhan/Applications/LearnStream/.nitro/cache"}));
storage.mount('data', unstorage_47drivers_47fs({"driver":"fs","base":"/Users/dhan/Applications/LearnStream/.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        } else if (opts._removeStaleOnInvalid?.(entry)) {
          const promise = useStorage().removeItem(cacheKey).catch((error) => {
            console.error(`[cache] Cache remove error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const _methodSuffix = event.method === "HEAD" ? ":HEAD" : "";
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey) + _methodSuffix;
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":") + _methodSuffix;
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      if (!isCacheableResponse(entry.value.headers, variableHeaderNames)) {
        return false;
      }
      return true;
    },
    _removeStaleOnInvalid: (entry) => !!entry.value && !isCacheableResponse(entry.value.headers, variableHeaderNames),
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _resolveResponse = async (incomingEvent) => {
    const variableHeaders = {};
    for (const header of variableHeaderNames) {
      const value = incomingEvent.node.req.headers[header];
      if (value !== void 0) {
        variableHeaders[header] = value;
      }
    }
    const reqProxy = cloneWithProxy(incomingEvent.node.req, {
      headers: variableHeaders
    });
    const resHeaders = {};
    let _resSendBody;
    const resProxy = cloneWithProxy(incomingEvent.node.res, {
      statusCode: 200,
      writableEnded: false,
      writableFinished: false,
      headersSent: false,
      closed: false,
      getHeader(name) {
        return resHeaders[name];
      },
      setHeader(name, value) {
        resHeaders[name] = value;
        return this;
      },
      getHeaderNames() {
        return Object.keys(resHeaders);
      },
      hasHeader(name) {
        return name in resHeaders;
      },
      removeHeader(name) {
        delete resHeaders[name];
      },
      appendHeader(name, value) {
        const values = [resHeaders[name], value].flat().filter((v) => v !== void 0).map(String);
        resHeaders[name] = values.length === 1 ? values[0] : values;
        return this;
      },
      getHeaders() {
        return resHeaders;
      },
      end(chunk, arg2, arg3) {
        if (typeof chunk === "string") {
          _resSendBody = chunk;
        }
        if (typeof arg2 === "function") {
          arg2();
        }
        if (typeof arg3 === "function") {
          arg3();
        }
        return this;
      },
      write(chunk, arg2, arg3) {
        if (typeof chunk === "string") {
          _resSendBody = chunk;
        }
        if (typeof arg2 === "function") {
          arg2(void 0);
        }
        if (typeof arg3 === "function") {
          arg3();
        }
        return true;
      },
      writeHead(statusCode, headers2) {
        this.statusCode = statusCode;
        if (headers2) {
          if (Array.isArray(headers2) || typeof headers2 === "string") {
            throw new TypeError("Raw headers  is not supported.");
          }
          for (const header in headers2) {
            const value = headers2[header];
            if (value !== void 0) {
              this.setHeader(header, value);
            }
          }
        }
        return this;
      }
    });
    const event = createEvent(reqProxy, resProxy);
    event._path = incomingEvent._path;
    event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
      fetch: useNitroApp().localFetch
    });
    event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
      fetch: globalThis.$fetch
    });
    event.waitUntil = incomingEvent.waitUntil;
    event.context = incomingEvent.context;
    event.context.cache = {
      options: _opts
    };
    const body = await handler(event) || _resSendBody;
    const headers = event.node.res.getHeaders();
    headers.etag = String(headers.Etag || headers.etag || `W/"${hash(body)}"`);
    headers["last-modified"] = String(
      headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
    );
    const cacheControl = [];
    if (!isCacheableResponse(headers, variableHeaderNames)) ; else if (opts.swr) {
      if (opts.maxAge) {
        cacheControl.push(`s-maxage=${opts.maxAge}`);
      }
      if (opts.staleMaxAge) {
        cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
      } else {
        cacheControl.push("stale-while-revalidate");
      }
    } else if (opts.maxAge) {
      cacheControl.push(`max-age=${opts.maxAge}`);
    }
    if (cacheControl.length > 0) {
      headers["cache-control"] = cacheControl.join(", ");
    }
    const cacheEntry = {
      code: event.node.res.statusCode,
      headers,
      body
    };
    responseOrigins.set(cacheEntry, incomingEvent);
    return cacheEntry;
  };
  const _cachedHandler = cachedFunction(
    // Anonymous wrapper keeps the default cache name (`fn.name` fallback) unchanged
    (event) => _resolveResponse(event),
    _opts
  );
  return defineEventHandler(async (event) => {
    if (event.method !== "GET" && event.method !== "HEAD" || event.node.req.headers.range !== void 0) {
      return handler(event);
    }
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    let response = await _cachedHandler(
      event
    );
    let isCacheable = isCacheableResponse(
      response.headers,
      variableHeaderNames
    );
    if (!isCacheable && responseOrigins.get(response) !== event) {
      response = await _resolveResponse(event);
      isCacheable = isCacheableResponse(response.headers, variableHeaderNames);
    }
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    const isOrigin = responseOrigins.get(response) === event;
    if (isCacheable && handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name.toLowerCase() === "set-cookie") {
        if (isOrigin && value !== void 0) {
          event.node.res.appendHeader(
            name,
            splitCookiesString(value)
          );
        }
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
const responseOrigins = /* @__PURE__ */ new WeakMap();
function getHeaderValue(headers, name) {
  const values = [];
  for (const key in headers) {
    if (key.toLowerCase() === name) {
      const value = headers[key];
      if (value !== void 0) {
        values.push(Array.isArray(value) ? value.join(", ") : String(value));
      }
    }
  }
  return values.length > 0 ? values.join(", ") : void 0;
}
const VARY_IGNORED_HEADERS = /* @__PURE__ */ new Set(["accept-encoding"]);
function isCacheableResponse(headers, variableHeaderNames) {
  if (getHeaderValue(headers, "set-cookie") !== void 0) {
    return false;
  }
  const cacheControl = getHeaderValue(headers, "cache-control");
  if (cacheControl && /(?:^|[\s,])(?:private|no-store|no-cache)(?:$|[\s,=])/i.test(cacheControl)) {
    return false;
  }
  const vary = getHeaderValue(headers, "vary");
  if (vary) {
    for (const _name of vary.split(",")) {
      const name = _name.trim().toLowerCase();
      if (!name || VARY_IGNORED_HEADERS.has(name)) {
        continue;
      }
      if (name === "*" || !variableHeaderNames.includes(name)) {
        return false;
      }
    }
  }
  return true;
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const inlineAppConfig = {};



const appConfig = defuFn(inlineAppConfig);

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/"
  },
  "nitro": {
    "routeRules": {}
  }
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  {
    return _sharedRuntimeConfig;
  }
}
_deepFreeze(klona(appConfig));
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

getContext("nitro-app", {
  asyncContext: undefined,
  AsyncLocalStorage: void 0
});

const MAX_DECODE_PASSES = 8;
const PERCENT_ESCAPE_RE = /%([\da-f]{2})/gi;
const HAS_PERCENT_ESCAPE_RE = /%[\da-f]{2}/i;
function canonicalizePath(pathname) {
  let path = pathname;
  for (let pass = 0; HAS_PERCENT_ESCAPE_RE.test(path); pass++) {
    if (pass >= MAX_DECODE_PASSES) {
      return void 0;
    }
    path = path.replace(
      PERCENT_ESCAPE_RE,
      (_, hex) => String.fromCharCode(Number.parseInt(hex, 16))
    );
  }
  const segments = [];
  for (const segment of path.replace(/\\/g, "/").split("/")) {
    if (segment === "" || segment === ".") {
      continue;
    }
    if (segment === "..") {
      segments.pop();
      continue;
    }
    segments.push(segment);
  }
  return "/" + segments.join("/");
}
function whatwgPathname(pathname) {
  try {
    return new URL(pathname, "http://_").pathname;
  } catch {
    return void 0;
  }
}
const READINGS = [
  (p) => canonicalizePath(p),
  (p) => {
    const whatwg = whatwgPathname(p);
    return whatwg === void 0 ? void 0 : canonicalizePath(whatwg);
  }
];
function isPathInScope(pathname, base) {
  if (!base || base === "/") {
    return true;
  }
  for (const read of READINGS) {
    const canonicalBase = read(base);
    const canonical = read(pathname);
    if (canonicalBase === void 0 || canonical === void 0) {
      return false;
    }
    if (canonicalBase === "/") {
      continue;
    }
    if (canonical !== canonicalBase && !canonical.startsWith(canonicalBase + "/")) {
      return false;
    }
  }
  return true;
}
function isTargetInScope(target, targetBase) {
  return isPathInScope(
    parseURL(target).pathname || "/",
    parseURL(targetBase).pathname || ""
  );
}
const LEADING_SEPARATORS_RE = (
  // eslint-disable-next-line no-control-regex
  /^(?:[\u0000-\u0020/\\]|%(?:2f|5c|[01][\da-f]|20))+/i
);
function normalizeRedirectPath(path) {
  return path.replace(LEADING_SEPARATORS_RE, "/");
}
function resolveRedirectTarget(path, to, stripBase) {
  if (!to.endsWith("/**")) {
    return path.includes("?") ? withQuery(to, getQuery(path)) : to;
  }
  let targetPath = path;
  if (stripBase) {
    if (!isPathInScope(path.split("?")[0], stripBase)) {
      return void 0;
    }
    targetPath = withoutBase(targetPath, stripBase);
  }
  targetPath = normalizeRedirectPath(targetPath);
  const targetBase = to.slice(0, -3);
  if (targetBase && targetBase !== "/" && !isPathInScope(joinURL("/_", targetPath.split("?")[0]), "/_")) {
    return void 0;
  }
  let target = joinURL(targetBase, targetPath);
  if (!targetBase || targetBase === "/") {
    target = normalizeRedirectPath(target);
    if (!target.startsWith("/")) {
      target = "/" + target;
    }
  }
  if (!isTargetInScope(target, targetBase)) {
    return void 0;
  }
  return target;
}

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      const target = resolveRedirectTarget(
        event.path,
        routeRules.redirect.to,
        routeRules.redirect._redirectStripBase
      );
      if (target === void 0) {
        throw createError({ statusCode: 400 });
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      const target = resolveRuleTarget(
        event,
        routeRules.proxy.to,
        routeRules.proxy._proxyStripBase
      );
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function resolveRuleTarget(event, to, stripBase) {
  if (!to.endsWith("/**")) {
    if (event.path.includes("?")) {
      return withQuery(to, getQuery(event.path));
    }
    return to;
  }
  const targetBase = to.slice(0, -3);
  let targetPath = event.path;
  if (stripBase) {
    if (!isPathInScope(event.path.split("?")[0], stripBase)) {
      throw createError({ statusCode: 400 });
    }
    targetPath = withoutBase(targetPath, stripBase);
  } else if (targetPath.startsWith("//")) {
    targetPath = targetPath.replace(/^\/+/, "/");
  }
  const target = joinURL(targetBase, targetPath);
  if (!isTargetInScope(target, targetBase)) {
    throw createError({ statusCode: 400 });
  }
  return target;
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$0 = defineNitroErrorHandler(
  async function defaultNitroErrorHandler(error, event) {
    const res = await defaultHandler(error, event);
    if (!event.node?.res.headersSent) {
      setResponseHeaders(event, res.headers);
    }
    setResponseStatus(event, res.status, res.statusText);
    return send(
      event,
      typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2)
    );
  }
);
async function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  await loadStackTrace(error).catch(consola.error);
  const youch = new Youch();
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    const ansiError = await (await youch.toANSI(error)).replaceAll(process.cwd(), ".");
    consola.error(
      `[request error] ${tags} [${event.method}] ${url}

`,
      ansiError
    );
  }
  const useJSON = opts?.json ?? !getRequestHeader(event, "accept")?.includes("text/html");
  const headers = {
    "content-type": useJSON ? "application/json" : "text/html",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'self';"
  };
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = useJSON ? {
    error: true,
    url,
    statusCode,
    statusMessage,
    message: error.message,
    data: error.data,
    stack: error.stack?.split("\n").map((line) => line.trim())
  } : await youch.toHTML(error, {
    request: {
      url: url.href,
      method: event.method,
      headers: getRequestHeaders(event)
    }
  });
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}
async function loadStackTrace(error) {
  if (!(error instanceof Error)) {
    return;
  }
  const consumerCache = /* @__PURE__ */ new Map();
  let parsed;
  try {
    parsed = await new ErrorParser().defineSourceLoader((frame) => sourceLoader(frame, consumerCache)).parse(error);
  } finally {
    for (const consumer of consumerCache.values()) {
      await consumer.then((c) => c?.destroy()).catch(() => {
      });
    }
  }
  const stack = error.message + "\n" + parsed.frames.map((frame) => fmtFrame(frame)).join("\n");
  Object.defineProperty(error, "stack", { value: stack });
  if (error.cause) {
    await loadStackTrace(error.cause).catch(consola.error);
  }
}
function loadConsumer(fileName, cache) {
  const cached = cache.get(fileName);
  if (cached) {
    return cached;
  }
  const promise = (async () => {
    const rawSourceMap = await readFile$1(`${fileName}.map`, "utf8").catch(
      () => {
      }
    );
    if (!rawSourceMap) {
      return void 0;
    }
    return await new SourceMapConsumer(rawSourceMap);
  })().catch(() => void 0);
  cache.set(fileName, promise);
  return promise;
}
async function sourceLoader(frame, consumerCache) {
  if (!frame.fileName || frame.fileType !== "fs" || frame.type === "native") {
    return;
  }
  if (frame.type === "app") {
    const bundleFileName = frame.fileName;
    try {
      const consumer = await loadConsumer(bundleFileName, consumerCache);
      if (consumer) {
        const originalPosition = consumer.originalPositionFor({ line: frame.lineNumber, column: frame.columnNumber });
        if (originalPosition.source && originalPosition.line) {
          frame.fileName = resolve(dirname(bundleFileName), originalPosition.source);
          frame.lineNumber = originalPosition.line;
          frame.columnNumber = originalPosition.column || 0;
        }
      }
    } catch {
    }
  }
  const contents = await readFile$1(frame.fileName, "utf8").catch(() => {
  });
  return contents ? { contents } : void 0;
}
function fmtFrame(frame) {
  if (frame.type === "native") {
    return frame.raw;
  }
  const src = `${frame.fileName || ""}:${frame.lineNumber}:${frame.columnNumber})`;
  return frame.functionName ? `at ${frame.functionName} (${src}` : `at ${src}`;
}

const errorHandlers = [errorHandler$0];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

const plugins = [
  
];

const assets = {
  "/index.mjs": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"13be6-qMKZA8fZjsrLet1F5cUsiKcUkOM\"",
    "mtime": "2026-11-18T10:26:19.934Z",
    "size": 80870,
    "path": "index.mjs"
  },
  "/index.mjs.map": {
    "type": "application/json",
    "etag": "\"4726e-NkVgsVhBkQUAuFAZyKCnltokxpM\"",
    "mtime": "2026-11-18T10:26:19.934Z",
    "size": 291438,
    "path": "index.mjs.map"
  }
};

function readAsset (id) {
  const serverDir = dirname$1(fileURLToPath(globalThis._importMeta_.url));
  // Public dirs might be pruned after the build (uploaded to a CDN, sourcemaps
  // stripped), so a manifest entry with no file behind it reads as absent, not broken.
  return promises.readFile(resolve$1(serverDir, assets[id].path)).catch((error) => {
    if (error?.code !== 'ENOENT') { throw error }
  })
}

const publicAssetBases = {};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _9S9CRX = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError({ statusCode: 404 });
    }
    return;
  }
  if (asset.encoding !== void 0) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  const data = readAsset(id);
  return typeof data?.then === "function" ? data.then(
    (resolved) => assertAssetData(event, resolved)
  ) : assertAssetData(event, data);
});
function assertAssetData(event, data) {
  if (data === null || data === void 0) {
    removeResponseHeader(event, "Cache-Control");
    throw createError({ statusCode: 404 });
  }
  return data;
}

const _lazy_hn2UeQ = () => Promise.resolve().then(function () { return signin_post$1; });
const _lazy_j4Uhk3 = () => Promise.resolve().then(function () { return signout_post$1; });
const _lazy_GYdupI = () => Promise.resolve().then(function () { return signup_post$1; });
const _lazy_kpOI_5 = () => Promise.resolve().then(function () { return health_get$1; });
const _lazy_Xy1EdM = () => Promise.resolve().then(function () { return me_get$1; });
const _lazy_lr7bLZ = () => Promise.resolve().then(function () { return subjects_get$1; });
const _lazy_mnbXSw = () => Promise.resolve().then(function () { return _id__get$1; });
const _lazy_ewcfx4 = () => Promise.resolve().then(function () { return comments_get$1; });
const _lazy_ypzuv9 = () => Promise.resolve().then(function () { return comments_post$1; });
const _lazy_jT_5wQ = () => Promise.resolve().then(function () { return reaction_put$1; });
const _lazy_JDDgVS = () => Promise.resolve().then(function () { return related_get$1; });
const _lazy_VVLyHL = () => Promise.resolve().then(function () { return saved_put$1; });
const _lazy_H_KGqP = () => Promise.resolve().then(function () { return views_post$1; });
const _lazy_QunyX8 = () => Promise.resolve().then(function () { return index_get$1; });
const _lazy_Jyzqbh = () => Promise.resolve().then(function () { return index_post$1; });
const _lazy_dAExOd = () => Promise.resolve().then(function () { return ____key_$1; });

const handlers = [
  { route: '', handler: _9S9CRX, lazy: false, middleware: true, method: undefined },
  { route: '/api/auth/signin', handler: _lazy_hn2UeQ, lazy: true, middleware: false, method: "post" },
  { route: '/api/auth/signout', handler: _lazy_j4Uhk3, lazy: true, middleware: false, method: "post" },
  { route: '/api/auth/signup', handler: _lazy_GYdupI, lazy: true, middleware: false, method: "post" },
  { route: '/api/health', handler: _lazy_kpOI_5, lazy: true, middleware: false, method: "get" },
  { route: '/api/me', handler: _lazy_Xy1EdM, lazy: true, middleware: false, method: "get" },
  { route: '/api/subjects', handler: _lazy_lr7bLZ, lazy: true, middleware: false, method: "get" },
  { route: '/api/videos/:id', handler: _lazy_mnbXSw, lazy: true, middleware: false, method: "get" },
  { route: '/api/videos/:id/comments', handler: _lazy_ewcfx4, lazy: true, middleware: false, method: "get" },
  { route: '/api/videos/:id/comments', handler: _lazy_ypzuv9, lazy: true, middleware: false, method: "post" },
  { route: '/api/videos/:id/reaction', handler: _lazy_jT_5wQ, lazy: true, middleware: false, method: "put" },
  { route: '/api/videos/:id/related', handler: _lazy_JDDgVS, lazy: true, middleware: false, method: "get" },
  { route: '/api/videos/:id/saved', handler: _lazy_VVLyHL, lazy: true, middleware: false, method: "put" },
  { route: '/api/videos/:id/views', handler: _lazy_H_KGqP, lazy: true, middleware: false, method: "post" },
  { route: '/api/videos', handler: _lazy_QunyX8, lazy: true, middleware: false, method: "get" },
  { route: '/api/videos', handler: _lazy_Jyzqbh, lazy: true, middleware: false, method: "post" },
  { route: '/media/**:key', handler: _lazy_dAExOd, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(true),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          _platform: fetchContext?._platform,
          // #3335
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp$1.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter$1({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => callNodeRequestHandler(
    nodeHandler,
    aRequest
  );
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return fetchNodeRequestHandler(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp$1 = createNitroApp();
function useNitroApp() {
  return nitroApp$1;
}
runNitroPlugins(nitroApp$1);

const scheduledTasks = false;

const tasks = {
  
};

const __runningTasks__ = {};
async function runTask(name, {
  payload = {},
  context = {}
} = {}) {
  if (__runningTasks__[name]) {
    return __runningTasks__[name];
  }
  if (!(name in tasks)) {
    throw createError({
      message: `Task \`${name}\` is not available!`,
      statusCode: 404
    });
  }
  if (!tasks[name].resolve) {
    throw createError({
      message: `Task \`${name}\` is not implemented!`,
      statusCode: 501
    });
  }
  const handler = await tasks[name].resolve();
  const taskEvent = { name, payload, context };
  __runningTasks__[name] = handler.run(taskEvent);
  try {
    const res = await __runningTasks__[name];
    return res;
  } finally {
    delete __runningTasks__[name];
  }
}

if (!globalThis.crypto) {
  globalThis.crypto = nodeCrypto.webcrypto;
}
const { NITRO_NO_UNIX_SOCKET, NITRO_DEV_WORKER_ID } = process.env;
trapUnhandledNodeErrors();
parentPort?.on("message", (msg) => {
  if (msg && msg.event === "shutdown") {
    shutdown();
  }
});
const nitroApp = useNitroApp();
const server = new Server(toNodeListener(nitroApp.h3App));
let listener;
const upgradedSockets = /* @__PURE__ */ new Set();
listen().catch(() => listen(
  true
  /* use random port */
)).catch((error) => {
  console.error("Dev worker failed to listen:", error);
  return shutdown();
});
nitroApp.router.get(
  "/_nitro/tasks",
  defineEventHandler(async (event) => {
    const _tasks = await Promise.all(
      Object.entries(tasks).map(async ([name, task]) => {
        const _task = await task.resolve?.();
        return [name, { description: _task?.meta?.description }];
      })
    );
    return {
      tasks: Object.fromEntries(_tasks),
      scheduledTasks
    };
  })
);
nitroApp.router.use(
  "/_nitro/tasks/:name",
  defineEventHandler(async (event) => {
    const name = getRouterParam(event, "name");
    const payload = {
      ...getQuery$1(event),
      ...await readBody(event).then((r) => r?.payload).catch(() => ({}))
    };
    return await runTask(name, { payload });
  })
);
function listen(useRandomPort = Boolean(
  NITRO_NO_UNIX_SOCKET || process.versions.webcontainer || "Bun" in globalThis && process.platform === "win32"
)) {
  return new Promise((resolve, reject) => {
    try {
      listener = server.listen(useRandomPort ? 0 : getSocketAddress(), () => {
        const address = server.address();
        parentPort?.postMessage({
          event: "listen",
          address: typeof address === "string" ? { socketPath: address } : { host: "localhost", port: address?.port }
        });
        resolve();
      });
    } catch (error) {
      reject(error);
    }
  });
}
function getSocketAddress() {
  const socketName = `nitro-worker-${process.pid}-${threadId}-${NITRO_DEV_WORKER_ID}-${Math.round(Math.random() * 1e4)}.sock`;
  if (process.platform === "win32") {
    return join(String.raw`\\.\pipe`, socketName);
  }
  if (process.platform === "linux") {
    const nodeMajor = Number.parseInt(process.versions.node.split(".")[0], 10);
    if (nodeMajor >= 20) {
      return `\0${socketName}`;
    }
  }
  return join(tmpdir(), socketName);
}
async function shutdown() {
  server.closeAllConnections?.();
  for (const socket of upgradedSockets) {
    socket.destroy();
  }
  await Promise.all([
    new Promise((resolve) => listener?.close(resolve)),
    nitroApp.hooks.callHook("close").catch(console.error)
  ]);
  parentPort?.postMessage({ event: "exit" });
}

var _a;
const globalForPrisma = globalThis;
const prisma = (_a = globalForPrisma.prisma) != null ? _a : new PrismaClient({
  log: ["error", "warn"]
});
{
  globalForPrisma.prisma = prisma;
}

const scryptAsync = promisify(scrypt);
const KEY_LENGTH = 64;
async function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const derived = await scryptAsync(password, salt, KEY_LENGTH);
  return `${salt}:${derived.toString("hex")}`;
}
async function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const expected = Buffer.from(hash, "hex");
  if (expected.length !== KEY_LENGTH) return false;
  const derived = await scryptAsync(password, salt, KEY_LENGTH);
  return timingSafeEqual(derived, expected);
}
function createSessionToken() {
  return randomBytes(32).toString("base64url");
}

function apiError(statusCode, code, message) {
  return createError({
    statusCode,
    statusMessage: message,
    data: { code, message }
  });
}
function badRequest(message, code = "invalid_input") {
  return apiError(400, code, message);
}
function unauthorized(message = "Sign in to continue.") {
  return apiError(401, "unauthorized", message);
}
function forbidden(message = "You do not have permission to do that.") {
  return apiError(403, "forbidden", message);
}
function notFound(message = "That lesson could not be found.") {
  return apiError(404, "not_found", message);
}

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const emailField = z.string().trim().max(254, "Keep your email under 254 characters.").regex(EMAIL_PATTERN, "Enter a valid email address.");
const signUpSchema = z.object({
  name: z.string().trim().min(2, "Enter the name you want learners to see.").max(80, "Keep your name under 80 characters."),
  email: emailField,
  password: z.string().min(8, "Use at least 8 characters for your password.").max(200),
  // Only the two self-service roles; `admin` is never chosen by a visitor.
  role: z.enum(["learner", "teacher"])
});
const signInSchema = z.object({
  email: emailField,
  password: z.string().min(1, "Enter your password.").max(200)
});
z.object({
  start: z.number().min(0),
  end: z.number().min(0),
  text: z.string().trim().min(1).max(500)
});
const videoFieldsSchema = z.object({
  title: z.string().trim().min(3, "Give your lesson a title of at least 3 characters.").max(140, "Keep the title under 140 characters."),
  description: z.string().trim().min(10, "Add a description of at least 10 characters.").max(5e3, "Keep the description under 5000 characters."),
  subjectSlug: z.string().trim().min(1, "Choose a subject.").max(60),
  tags: z.array(z.string().trim().min(1).max(30)).max(8, "Use at most 8 tags.").default([])
});
const reactionSchema = z.object({
  kind: z.enum(["like", "dislike"]).nullable()
});
const savedToggleSchema = z.object({
  saved: z.boolean()
});
const commentSchema = z.object({
  body: z.string().trim().min(2, "Write at least 2 characters.").max(2e3, "Keep it under 2000 characters.")
});
function firstIssue(error) {
  var _a, _b;
  return (_b = (_a = error.issues[0]) == null ? void 0 : _a.message) != null ? _b : "That input was not valid.";
}
function parseOrThrow(schema, value) {
  const result = schema.safeParse(value);
  if (!result.success) throw badRequest(firstIssue(result.error));
  return result.data;
}

const VIEW_DEDUPE_WINDOW_MS = 30 * 60 * 1e3;
const MAX_UPLOAD_BYTES = 256 * 1024 * 1024;
const ALLOWED_VIDEO_TYPES = ["video/mp4", "video/webm"];
const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
const SESSION_COOKIE = "learnstream_session";
function sessionTtlDays() {
  var _a;
  const parsed = Number.parseInt((_a = process.env.SESSION_TTL_DAYS) != null ? _a : "", 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 30;
}
function mediaRoot() {
  return resolve(process.cwd(), process.env.MEDIA_DIR || "server/storage/media");
}
function isProduction() {
  return false;
}
function viewerSecret() {
  return process.env.VIEWER_SECRET || "learnstream-development-viewer-secret";
}

const ROLES = ["learner", "teacher", "admin"];
function isRole(value) {
  return ROLES.includes(value);
}
function initialsFor(name) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "LS";
  const first = parts[0].charAt(0);
  const last = parts.length > 1 ? parts[parts.length - 1].charAt(0) : "";
  return `${first}${last}`.toUpperCase();
}
function toPublicUser(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    initials: initialsFor(user.name),
    role: isRole(user.role) ? user.role : "learner"
  };
}
async function startSession(event, userId) {
  const token = createSessionToken();
  const expiresAt = new Date(Date.now() + sessionTtlDays() * 24 * 60 * 60 * 1e3);
  await prisma.session.create({ data: { id: token, userId, expiresAt } });
  setCookie(event, SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    secure: isProduction(),
    expires: expiresAt
  });
}
async function currentUser(event) {
  const token = getCookie(event, SESSION_COOKIE);
  if (!token) return null;
  const session = await prisma.session.findUnique({
    where: { id: token },
    include: { user: true }
  });
  if (!session) return null;
  if (session.expiresAt.getTime() <= Date.now()) {
    await prisma.session.deleteMany({ where: { id: token } });
    deleteCookie(event, SESSION_COOKIE, { path: "/" });
    return null;
  }
  return session.user;
}
async function requireUser(event) {
  const user = await currentUser(event);
  if (!user) throw unauthorized();
  return user;
}
async function endSession(event) {
  const token = getCookie(event, SESSION_COOKIE);
  if (token) await prisma.session.deleteMany({ where: { id: token } });
  deleteCookie(event, SESSION_COOKIE, { path: "/" });
}

const signin_post = defineEventHandler(async (event) => {
  const input = parseOrThrow(signInSchema, await readBody(event));
  const failure = apiError(401, "invalid_credentials", "Email or password is incorrect.");
  const user = await prisma.user.findUnique({ where: { email: input.email.toLowerCase() } });
  if (!user) throw failure;
  const matches = await verifyPassword(input.password, user.passwordHash);
  if (!matches) throw failure;
  await startSession(event, user.id);
  return { user: toPublicUser(user) };
});

const signin_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: signin_post
});

const signout_post = defineEventHandler(async (event) => {
  await endSession(event);
  return { ok: true };
});

const signout_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: signout_post
});

const signup_post = defineEventHandler(async (event) => {
  const input = parseOrThrow(signUpSchema, await readBody(event));
  const email = input.email.toLowerCase();
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    throw apiError(
      409,
      "email_taken",
      "An account with that email already exists \u2014 sign in instead."
    );
  }
  const user = await prisma.user.create({
    data: {
      name: input.name,
      email,
      passwordHash: await hashPassword(input.password),
      role: input.role
    }
  });
  await startSession(event, user.id);
  return { user: toPublicUser(user) };
});

const signup_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: signup_post
});

const health_get = defineEventHandler(async (_event) => {
  await prisma.$queryRaw`SELECT 1`;
  return {
    status: "ok",
    database: "up",
    time: (/* @__PURE__ */ new Date()).toISOString()
  };
});

const health_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: health_get
});

const me_get = defineEventHandler(async (event) => {
  const user = await currentUser(event);
  if (!user) return { user: null, saved: [], reactions: {} };
  const [saved, reactions] = await Promise.all([
    prisma.savedVideo.findMany({ where: { userId: user.id }, orderBy: { savedAt: "desc" } }),
    prisma.reaction.findMany({ where: { userId: user.id } })
  ]);
  return {
    user: toPublicUser(user),
    saved: saved.map((entry) => ({
      videoId: entry.videoId,
      savedAt: entry.savedAt.toISOString()
    })),
    reactions: Object.fromEntries(reactions.map((row) => [row.videoId, row.kind]))
  };
});

const me_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: me_get
});

function mediaUrl(key) {
  return key ? `/media/${key}` : "";
}
function toVideoDto(row) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i;
  const captions = (_a = row.captions) == null ? void 0 : _a.map((cue) => ({
    start: cue.start,
    end: cue.end,
    text: cue.text
  }));
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    subjectSlug: row.subject.slug,
    tags: row.tags.map((tag) => tag.name),
    uploaderId: row.uploader.id,
    uploaderName: row.uploader.name,
    src: mediaUrl((_c = (_b = row.metadata) == null ? void 0 : _b.storageKey) != null ? _c : null),
    thumbnail: (_g = (_d = row.metadata) == null ? void 0 : _d.thumbnailUrl) != null ? _g : mediaUrl((_f = (_e = row.metadata) == null ? void 0 : _e.thumbnailKey) != null ? _f : null),
    durationSec: (_i = (_h = row.metadata) == null ? void 0 : _h.durationSec) != null ? _i : 0,
    views: row.viewCount,
    likes: row.likeCount,
    dislikes: row.dislikeCount,
    createdAt: row.createdAt.toISOString(),
    status: row.status === "published" ? "published" : "processing",
    ...captions && captions.length ? { captions } : {}
  };
}
function toSubjectDto(row) {
  return { id: row.id, slug: row.slug, name: row.name, icon: row.icon, tagline: row.tagline };
}
function toCommentDto(row) {
  return {
    id: row.id,
    videoId: row.videoId,
    authorName: row.authorName,
    body: row.body,
    createdAt: row.createdAt.toISOString()
  };
}

const subjects_get = defineEventHandler(async (_event) => {
  const [subjects, counts] = await Promise.all([
    prisma.subject.findMany({ orderBy: { name: "asc" } }),
    prisma.video.groupBy({
      by: ["subjectId"],
      where: { status: "published" },
      _count: { _all: true }
    })
  ]);
  const countBySubject = new Map(counts.map((row) => [row.subjectId, row._count._all]));
  return {
    subjects: subjects.map((subject) => {
      var _a;
      return {
        ...toSubjectDto(subject),
        videoCount: (_a = countBySubject.get(subject.id)) != null ? _a : 0
      };
    })
  };
});

const subjects_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: subjects_get
});

const listInclude = {
  subject: true,
  uploader: true,
  tags: true,
  metadata: true
};
const MAX_LIST_ROWS = 500;
const SORTS = ["newest", "views", "likes", "rated"];
const RANGE_DAYS = { week: 7, month: 30, year: 365 };
const DAY_MS = 864e5;
function readParam(query, key) {
  const value = query[key];
  return typeof value === "string" ? value.trim() : "";
}
function readCatalogFilters(event) {
  const query = getQuery$1(event);
  const sort = readParam(query, "sort");
  const days = RANGE_DAYS[readParam(query, "range")];
  return {
    subjectSlug: readParam(query, "subject") || void 0,
    search: readParam(query, "q") || void 0,
    sort: SORTS.includes(sort) ? sort : "newest",
    since: days ? new Date(Date.now() - days * DAY_MS) : void 0,
    uploaderId: readParam(query, "uploader") || void 0
  };
}
function buildWhere(filters) {
  var _a;
  const where = {};
  if (!filters.includeProcessing) where.status = "published";
  if (filters.subjectSlug) where.subject = { slug: filters.subjectSlug };
  if (filters.uploaderId) where.uploaderId = filters.uploaderId;
  if (filters.since) where.createdAt = { gte: filters.since };
  const term = (_a = filters.search) == null ? void 0 : _a.trim();
  if (term) {
    where.OR = [
      { title: { contains: term } },
      { description: { contains: term } },
      { uploader: { name: { contains: term } } },
      { subject: { name: { contains: term } } },
      { tags: { some: { name: { contains: term } } } }
    ];
  }
  return where;
}
function likeRatio(video) {
  const votes = video.likes + video.dislikes;
  return votes === 0 ? 0 : video.likes / votes;
}
function sortVideos(list, sort) {
  const sorted = [...list];
  switch (sort) {
    case "views":
      return sorted.sort((a, b) => b.views - a.views);
    case "likes":
      return sorted.sort((a, b) => b.likes - a.likes);
    case "rated":
      return sorted.sort((a, b) => likeRatio(b) - likeRatio(a) || b.likes - a.likes);
    case "newest":
      return sorted.sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
  }
}
async function listVideos(filters) {
  var _a;
  const rows = await prisma.video.findMany({
    where: buildWhere(filters),
    include: listInclude,
    take: MAX_LIST_ROWS
  });
  return sortVideos(rows.map(toVideoDto), (_a = filters.sort) != null ? _a : "newest");
}
async function findVideo(id) {
  const row = await prisma.video.findUnique({
    where: { id },
    include: { ...listInclude, captions: { orderBy: { position: "asc" } } }
  });
  return row ? toVideoDto(row) : null;
}
async function relatedVideos(videoId, subjectSlug, limit = 6) {
  const sameSubject = await prisma.video.findMany({
    where: { status: "published", subject: { slug: subjectSlug }, id: { not: videoId } },
    include: listInclude,
    orderBy: { viewCount: "desc" },
    take: limit
  });
  if (sameSubject.length >= limit) return sameSubject.map(toVideoDto);
  const filler = await prisma.video.findMany({
    where: {
      status: "published",
      id: { notIn: [videoId, ...sameSubject.map((row) => row.id)] },
      subject: { slug: { not: subjectSlug } }
    },
    include: listInclude,
    orderBy: { viewCount: "desc" },
    take: limit - sameSubject.length
  });
  return [...sameSubject, ...filler].map(toVideoDto);
}

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw notFound();
  const video = await findVideo(id);
  if (!video) throw notFound();
  if (video.status !== "published") {
    const user = await currentUser(event);
    if (!user || user.id !== video.uploaderId) {
      throw notFound("That lesson is still being processed and is not available yet.");
    }
  }
  return { video };
});

const _id__get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: _id__get
});

const comments_get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw notFound();
  const exists = await prisma.video.findUnique({ where: { id }, select: { id: true } });
  if (!exists) throw notFound();
  const comments = await prisma.comment.findMany({
    where: { videoId: id },
    orderBy: { createdAt: "asc" }
  });
  return { comments: comments.map(toCommentDto) };
});

const comments_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: comments_get
});

const comments_post = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw notFound();
  const user = await requireUser(event);
  const { body } = parseOrThrow(commentSchema, await readBody(event));
  const exists = await prisma.video.findUnique({ where: { id }, select: { id: true } });
  if (!exists) throw notFound();
  const comment = await prisma.comment.create({
    data: { videoId: id, userId: user.id, authorName: user.name, body }
  });
  return { comment: toCommentDto(comment) };
});

const comments_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: comments_post
});

const reaction_put = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw notFound();
  const user = await requireUser(event);
  const { kind } = parseOrThrow(reactionSchema, await readBody(event));
  const exists = await prisma.video.findUnique({ where: { id }, select: { id: true } });
  if (!exists) throw notFound();
  const totals = await prisma.$transaction(async (tx) => {
    const existing = await tx.reaction.findUnique({
      where: { videoId_userId: { videoId: id, userId: user.id } },
      select: { kind: true }
    });
    if ((existing == null ? void 0 : existing.kind) === kind) {
      const video = await tx.video.findUniqueOrThrow({
        where: { id },
        select: { likeCount: true, dislikeCount: true }
      });
      return video;
    }
    const data = {};
    if ((existing == null ? void 0 : existing.kind) === "like") data.likeCount = { increment: -1 };
    if ((existing == null ? void 0 : existing.kind) === "dislike") data.dislikeCount = { increment: -1 };
    if (kind === "like") data.likeCount = { increment: 1 };
    if (kind === "dislike") data.dislikeCount = { increment: 1 };
    if (kind === null) {
      await tx.reaction.deleteMany({ where: { videoId: id, userId: user.id } });
    } else {
      await tx.reaction.upsert({
        where: { videoId_userId: { videoId: id, userId: user.id } },
        create: { videoId: id, userId: user.id, kind },
        update: { kind }
      });
    }
    return tx.video.update({
      where: { id },
      data,
      select: { likeCount: true, dislikeCount: true }
    });
  });
  return { likes: totals.likeCount, dislikes: totals.dislikeCount, reaction: kind };
});

const reaction_put$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: reaction_put
});

const related_get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw notFound();
  const video = await findVideo(id);
  if (!video) throw notFound();
  return { videos: await relatedVideos(video.id, video.subjectSlug) };
});

const related_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: related_get
});

const saved_put = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw notFound();
  const user = await requireUser(event);
  const { saved } = parseOrThrow(savedToggleSchema, await readBody(event));
  const exists = await prisma.video.findUnique({ where: { id }, select: { id: true } });
  if (!exists) throw notFound();
  if (saved) {
    await prisma.savedVideo.upsert({
      where: { videoId_userId: { videoId: id, userId: user.id } },
      create: { videoId: id, userId: user.id },
      update: {}
    });
  } else {
    await prisma.savedVideo.deleteMany({ where: { videoId: id, userId: user.id } });
  }
  return { saved };
});

const saved_put$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: saved_put
});

function viewerKey(event) {
  var _a, _b;
  const address = (_a = getRequestIP(event, { xForwardedFor: true })) != null ? _a : "unknown";
  const agent = (_b = getRequestHeader(event, "user-agent")) != null ? _b : "unknown";
  return createHash("sha256").update(`${viewerSecret()}:${address}:${agent}`).digest("hex");
}

const views_post = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw notFound();
  const exists = await prisma.video.findUnique({ where: { id }, select: { id: true } });
  if (!exists) throw notFound();
  const user = await currentUser(event);
  const viewer = viewerKey(event);
  const since = new Date(Date.now() - VIEW_DEDUPE_WINDOW_MS);
  const views = await prisma.$transaction(async (tx) => {
    var _a, _b;
    const recent = await tx.view.findFirst({
      where: { videoId: id, viewerKey: viewer, createdAt: { gte: since } },
      select: { id: true }
    });
    if (recent) {
      const video = await tx.video.findUnique({ where: { id }, select: { viewCount: true } });
      return (_a = video == null ? void 0 : video.viewCount) != null ? _a : 0;
    }
    await tx.view.create({ data: { videoId: id, userId: (_b = user == null ? void 0 : user.id) != null ? _b : null, viewerKey: viewer } });
    const updated = await tx.video.update({
      where: { id },
      data: { viewCount: { increment: 1 } },
      select: { viewCount: true }
    });
    return updated.viewCount;
  });
  return { views };
});

const views_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: views_post
});

const index_get = defineEventHandler(async (event) => {
  const filters = readCatalogFilters(event);
  if (filters.uploaderId === "me") {
    const user = await currentUser(event);
    filters.uploaderId = user == null ? void 0 : user.id;
    filters.includeProcessing = Boolean(user);
  }
  return { videos: await listVideos(filters) };
});

const index_get$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index_get
});

function storagePath(key) {
  return resolve(mediaRoot(), key);
}
function isInsideMediaRoot(key) {
  const root = mediaRoot();
  const target = storagePath(key);
  return target === root || target.startsWith(root + sep);
}
function newStorageKey(folder, extension) {
  return `${folder}/${randomUUID()}${extension}`;
}
const EXTENSION_BY_MIME = {
  "video/mp4": ".mp4",
  "video/webm": ".webm",
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp"
};
function extensionFor(fileName, mimeType) {
  var _a;
  const fromName = fileName ? extname(fileName).toLowerCase() : "";
  if (/^\.[a-z0-9]{1,5}$/.test(fromName)) return fromName;
  return (_a = EXTENSION_BY_MIME[mimeType]) != null ? _a : "";
}
async function saveUpload(key, data) {
  const target = storagePath(key);
  await mkdir(dirname(target), { recursive: true });
  await writeFile(target, data);
}
async function removeUpload(key) {
  if (!isInsideMediaRoot(key)) return;
  await rm(storagePath(key), { force: true });
}

function slugify(value) {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

function readField(parts, name) {
  const part = parts.find((item) => item.name === name && !item.filename);
  return part ? part.data.toString("utf8").trim() : "";
}
function readFile(parts, name) {
  return parts.find((item) => item.name === name && Boolean(item.filename));
}
function readTags(parts) {
  return readField(parts, "tags").split(",").map((tag) => tag.trim()).filter(Boolean);
}
const index_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h;
  const user = await requireUser(event);
  if (user.role !== "teacher" && user.role !== "admin") {
    throw forbidden("Only uploader accounts can publish lessons. Switch to an uploader account to continue.");
  }
  const declaredSize = Number.parseInt((_a = getRequestHeader(event, "content-length")) != null ? _a : "", 10);
  if (Number.isFinite(declaredSize) && declaredSize > MAX_UPLOAD_BYTES) {
    throw apiError(413, "file_too_large", "That file is larger than the 256 MB limit.");
  }
  const parts = (_b = await readMultipartFormData(event)) != null ? _b : [];
  const fields = parseOrThrow(videoFieldsSchema, {
    title: readField(parts, "title"),
    description: readField(parts, "description"),
    subjectSlug: readField(parts, "subject"),
    tags: readTags(parts)
  });
  const subject = await prisma.subject.findUnique({ where: { slug: fields.subjectSlug } });
  if (!subject) throw notFound("That subject does not exist.");
  const videoPart = readFile(parts, "file");
  if (!videoPart) throw apiError(400, "file_missing", "Choose a video file to upload.");
  if (videoPart.data.length > MAX_UPLOAD_BYTES) {
    throw apiError(413, "file_too_large", "That file is larger than the 256 MB limit.");
  }
  if (!ALLOWED_VIDEO_TYPES.includes((_c = videoPart.type) != null ? _c : "")) {
    throw apiError(415, "unsupported_type", "Upload an MP4 or WebM video.");
  }
  const thumbnailPart = readFile(parts, "thumbnail");
  if (thumbnailPart && !ALLOWED_IMAGE_TYPES.includes((_d = thumbnailPart.type) != null ? _d : "")) {
    throw apiError(415, "unsupported_type", "Upload a JPEG, PNG or WebP image for the poster.");
  }
  const videoKey = newStorageKey("videos", extensionFor(videoPart.filename, (_e = videoPart.type) != null ? _e : ""));
  const thumbnailKey = thumbnailPart ? newStorageKey("thumbnails", extensionFor(thumbnailPart.filename, (_f = thumbnailPart.type) != null ? _f : "")) : null;
  await saveUpload(videoKey, videoPart.data);
  if (thumbnailPart && thumbnailKey) await saveUpload(thumbnailKey, thumbnailPart.data);
  try {
    const created = await prisma.video.create({
      data: {
        title: fields.title,
        description: fields.description,
        // Stored, then flipped to `published` below — the file is already safe
        // on disk at this point, so `processing` is never seen by a visitor.
        status: "processing",
        subjectId: subject.id,
        uploaderId: user.id,
        metadata: {
          create: {
            storageKey: videoKey,
            fileName: (_g = videoPart.filename) != null ? _g : null,
            mimeType: (_h = videoPart.type) != null ? _h : null,
            sizeBytes: videoPart.data.length,
            thumbnailKey
          }
        },
        tags: {
          connectOrCreate: fields.tags.map((tag) => ({
            where: { slug: slugify(tag) },
            create: { slug: slugify(tag), name: tag }
          }))
        }
      },
      include: { subject: true, uploader: true, tags: true, metadata: true }
    });
    const published = await prisma.video.update({
      where: { id: created.id },
      data: { status: "published" },
      include: { subject: true, uploader: true, tags: true, metadata: true }
    });
    return { video: toVideoDto(published) };
  } catch (error) {
    await removeUpload(videoKey);
    if (thumbnailKey) await removeUpload(thumbnailKey);
    throw error;
  }
});

const index_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: index_post
});

const MIME_BY_EXT = {
  ".mp4": "video/mp4",
  ".webm": "video/webm",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp"
};
function parseRange(header, size) {
  const match = /^bytes=(\d*)-(\d*)$/.exec(header.trim());
  if (!match) return null;
  const [, rawStart, rawEnd] = match;
  if (rawStart === "" && rawEnd === "") return null;
  let start;
  let end;
  if (rawStart === "") {
    const length = Number.parseInt(rawEnd, 10);
    if (!Number.isFinite(length) || length <= 0) return null;
    start = Math.max(0, size - length);
    end = size - 1;
  } else {
    start = Number.parseInt(rawStart, 10);
    end = rawEnd === "" ? size - 1 : Number.parseInt(rawEnd, 10);
  }
  if (!Number.isFinite(start) || !Number.isFinite(end)) return null;
  if (start < 0 || start >= size || end < start) return null;
  return { start, end: Math.min(end, size - 1) };
}
const ____key_ = defineEventHandler(async (event) => {
  var _a, _b;
  const key = (_a = getRouterParam(event, "key")) != null ? _a : "";
  const missing = apiError(404, "not_found", "That file could not be found.");
  if (!key || !isInsideMediaRoot(key)) throw missing;
  const path = storagePath(key);
  const info = await stat(path).catch(() => null);
  if (!(info == null ? void 0 : info.isFile())) throw missing;
  const size = info.size;
  const contentType = (_b = MIME_BY_EXT[extname(path).toLowerCase()]) != null ? _b : "application/octet-stream";
  const isHead = event.method === "HEAD";
  setResponseHeader(event, "content-type", contentType);
  setResponseHeader(event, "accept-ranges", "bytes");
  setResponseHeader(event, "cache-control", "public, max-age=3600");
  const header = getRequestHeader(event, "range");
  const range = header ? parseRange(header, size) : null;
  if (header && !range) {
    setResponseStatus(event, 416);
    setResponseHeader(event, "content-range", `bytes */${size}`);
    return "";
  }
  if (range) {
    setResponseStatus(event, 206);
    setResponseHeader(event, "content-range", `bytes ${range.start}-${range.end}/${size}`);
    setResponseHeader(event, "content-length", range.end - range.start + 1);
    if (isHead) return "";
    return sendStream(event, createReadStream(path, { start: range.start, end: range.end }));
  }
  setResponseHeader(event, "content-length", size);
  if (isHead) return "";
  return sendStream(event, createReadStream(path));
});

const ____key_$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  default: ____key_
});
//# sourceMappingURL=index.mjs.map
