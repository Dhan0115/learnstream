import { z } from 'zod'
import { badRequest } from './errors'

/**
 * Input validation for every mutating endpoint (AGENTS.md §2.3).
 *
 * Client-side checks mirror these rules so a learner gets instant feedback, but
 * the server never trusts what it receives — the schemas below are the boundary.
 */

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

export const emailField = z
  .string()
  .trim()
  .max(254, 'Keep your email under 254 characters.')
  .regex(EMAIL_PATTERN, 'Enter a valid email address.')

export const signUpSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, 'Enter the name you want learners to see.')
    .max(80, 'Keep your name under 80 characters.'),
  email: emailField,
  password: z.string().min(8, 'Use at least 8 characters for your password.').max(200),
  // Only the two self-service roles; `admin` is never chosen by a visitor.
  role: z.enum(['learner', 'teacher'])
})

export const signInSchema = z.object({
  email: emailField,
  password: z.string().min(1, 'Enter your password.').max(200)
})

export const captionCueSchema = z.object({
  start: z.number().min(0),
  end: z.number().min(0),
  text: z.string().trim().min(1).max(500)
})

export const videoFieldsSchema = z.object({
  title: z
    .string()
    .trim()
    .min(3, 'Give your lesson a title of at least 3 characters.')
    .max(140, 'Keep the title under 140 characters.'),
  description: z
    .string()
    .trim()
    .min(10, 'Add a description of at least 10 characters.')
    .max(5000, 'Keep the description under 5000 characters.'),
  subjectSlug: z.string().trim().min(1, 'Choose a subject.').max(60),
  tags: z.array(z.string().trim().min(1).max(30)).max(8, 'Use at most 8 tags.').default([])
})

/** `null` clears the vote — clicking an active reaction removes it. */
export const reactionSchema = z.object({
  kind: z.enum(['like', 'dislike']).nullable()
})

/** Saving and unsaving are one endpoint, so the intent is explicit. */
export const savedToggleSchema = z.object({
  saved: z.boolean()
})

export const commentSchema = z.object({
  body: z.string().trim().min(2, 'Write at least 2 characters.').max(2000, 'Keep it under 2000 characters.')
})

/** The first message is the one nearest the field that failed, so it is the one shown. */
export function firstIssue(error: z.ZodError): string {
  return error.issues[0]?.message ?? 'That input was not valid.'
}

/** Parse, or fail the request with 400 and a sentence the UI can show. */
export function parseOrThrow<T>(schema: z.ZodType<T>, value: unknown): T {
  const result = schema.safeParse(value)
  if (!result.success) throw badRequest(firstIssue(result.error))
  return result.data
}
