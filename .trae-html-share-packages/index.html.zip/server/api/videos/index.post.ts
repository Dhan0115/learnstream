import { readMultipartFormData, type H3Event, type MultiPartData } from 'h3'
import { prisma } from '../../utils/prisma'
import { requireUser } from '../../utils/session'
import { parseOrThrow, videoFieldsSchema } from '../../utils/validation'
import { apiError, forbidden, notFound } from '../../utils/errors'
import {
  ALLOWED_IMAGE_TYPES,
  ALLOWED_VIDEO_TYPES,
  MAX_UPLOAD_BYTES
} from '../../utils/config'
import { extensionFor, newStorageKey, removeUpload, saveUpload } from '../../utils/storage'
import { slugify } from '../../utils/slug'
import { toVideoDto } from '../../utils/serialize'

/** Reads a text field out of a multipart body (files carry a filename). */
function readField(parts: MultiPartData[], name: string): string {
  const part = parts.find(item => item.name === name && !item.filename)
  return part ? part.data.toString('utf8').trim() : ''
}

function readFile(parts: MultiPartData[], name: string): MultiPartData | undefined {
  return parts.find(item => item.name === name && Boolean(item.filename))
}

/** `"python, beginner"` → `['python', 'beginner']`. */
function readTags(parts: MultiPartData[]): string[] {
  return readField(parts, 'tags')
    .split(',')
    .map(tag => tag.trim())
    .filter(Boolean)
}

/**
 * Publish a lesson (design_spec.md §4.5).
 *
 * The file is validated and written to disk first, and only then does the row
 * become `published` — a lesson that failed to store is never listed. If the
 * database write fails, the file is removed so a retry starts clean.
 */
export default defineEventHandler(async (event: H3Event) => {
  const user = await requireUser(event)

  // Uploading is an uploader action; learners watch and save.
  if (user.role !== 'teacher' && user.role !== 'admin') {
    throw forbidden('Only uploader accounts can publish lessons. Switch to an uploader account to continue.')
  }

  // Reject an oversized body before it is buffered into memory.
  const declaredSize = Number.parseInt(getRequestHeader(event, 'content-length') ?? '', 10)
  if (Number.isFinite(declaredSize) && declaredSize > MAX_UPLOAD_BYTES) {
    throw apiError(413, 'file_too_large', 'That file is larger than the 256 MB limit.')
  }

  const parts = (await readMultipartFormData(event)) ?? []

  const fields = parseOrThrow(videoFieldsSchema, {
    title: readField(parts, 'title'),
    description: readField(parts, 'description'),
    subjectSlug: readField(parts, 'subject'),
    tags: readTags(parts)
  })

  const subject = await prisma.subject.findUnique({ where: { slug: fields.subjectSlug } })
  if (!subject) throw notFound('That subject does not exist.')

  const videoPart = readFile(parts, 'file')
  if (!videoPart) throw apiError(400, 'file_missing', 'Choose a video file to upload.')
  if (videoPart.data.length > MAX_UPLOAD_BYTES) {
    throw apiError(413, 'file_too_large', 'That file is larger than the 256 MB limit.')
  }
  if (!(ALLOWED_VIDEO_TYPES as readonly string[]).includes(videoPart.type ?? '')) {
    throw apiError(415, 'unsupported_type', 'Upload an MP4 or WebM video.')
  }

  const thumbnailPart = readFile(parts, 'thumbnail')
  if (thumbnailPart && !(ALLOWED_IMAGE_TYPES as readonly string[]).includes(thumbnailPart.type ?? '')) {
    throw apiError(415, 'unsupported_type', 'Upload a JPEG, PNG or WebP image for the poster.')
  }

  // Keys are generated here and never taken from the request, so a filename
  // such as `../../etc/passwd` cannot escape the media root.
  const videoKey = newStorageKey('videos', extensionFor(videoPart.filename, videoPart.type ?? ''))
  const thumbnailKey = thumbnailPart
    ? newStorageKey('thumbnails', extensionFor(thumbnailPart.filename, thumbnailPart.type ?? ''))
    : null

  await saveUpload(videoKey, videoPart.data)
  if (thumbnailPart && thumbnailKey) await saveUpload(thumbnailKey, thumbnailPart.data)

  try {
    const created = await prisma.video.create({
      data: {
        title: fields.title,
        description: fields.description,
        // Stored, then flipped to `published` below — the file is already safe
        // on disk at this point, so `processing` is never seen by a visitor.
        status: 'processing',
        subjectId: subject.id,
        uploaderId: user.id,
        metadata: {
          create: {
            storageKey: videoKey,
            fileName: videoPart.filename ?? null,
            mimeType: videoPart.type ?? null,
            sizeBytes: videoPart.data.length,
            thumbnailKey
          }
        },
        tags: {
          connectOrCreate: fields.tags.map(tag => ({
            where: { slug: slugify(tag) },
            create: { slug: slugify(tag), name: tag }
          }))
        }
      },
      include: { subject: true, uploader: true, tags: true, metadata: true }
    })

    const published = await prisma.video.update({
      where: { id: created.id },
      data: { status: 'published' },
      include: { subject: true, uploader: true, tags: true, metadata: true }
    })

    return { video: toVideoDto(published) }
  } catch (error) {
    // Nothing references the files yet, so a failed publish leaves no orphan.
    await removeUpload(videoKey)
    if (thumbnailKey) await removeUpload(thumbnailKey)
    throw error
  }
})
