import type { H3Event } from 'h3'
import { findVideo } from '../../utils/catalog'
import { currentUser } from '../../utils/session'
import { notFound } from '../../utils/errors'

/**
 * One lesson, for the watch page.
 *
 * A lesson that is still processing is hidden from everyone except the person
 * who uploaded it — that is the "unavailable video" case the UI renders.
 */
export default defineEventHandler(async (event: H3Event) => {
  const id = getRouterParam(event, 'id')
  if (!id) throw notFound()

  const video = await findVideo(id)
  if (!video) throw notFound()

  if (video.status !== 'published') {
    const user = await currentUser(event)
    if (!user || user.id !== video.uploaderId) {
      throw notFound('That lesson is still being processed and is not available yet.')
    }
  }

  return { video }
})
