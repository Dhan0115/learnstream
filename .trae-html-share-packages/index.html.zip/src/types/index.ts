// Domain types for LearnStream's mock data layer (design_spec.md §7).

export type Role = 'learner' | 'teacher' | 'admin'

export type VideoStatus = 'published' | 'processing'

export interface User {
  id: string
  /** Display name shown on the profile, dashboard and comments. */
  name: string
  /** The account identifier a learner signs in with. */
  email: string
  /** Monogram fallback when no image is available. */
  initials: string
  role: Role
}

export interface Subject {
  id: string
  slug: string
  name: string
  /** Monogram shown in the subject tile (design_spec.md §8.7). */
  icon: string
  tagline: string
}

/** A single timed caption/transcript cue, in seconds. */
export interface CaptionCue {
  start: number
  end: number
  text: string
}

export interface Video {
  id: string
  title: string
  description: string
  subjectSlug: string
  tags: string[]
  uploaderId: string
  uploaderName: string
  /** Empty for seeded demo lessons (design_spec.md §8.1). */
  src: string
  thumbnail: string
  durationSec: number
  views: number
  likes: number
  dislikes: number
  /** ISO 8601. */
  createdAt: string
  status: VideoStatus
  /** Present only when a caption track has been authored. */
  captions?: CaptionCue[]
}

export interface Comment {
  id: string
  videoId: string
  authorName: string
  body: string
  /** ISO 8601. */
  createdAt: string
}

/** `rated` is the like-to-vote ratio (Top Rated); the rest are raw totals. */
export type SortKey = 'newest' | 'views' | 'likes' | 'rated'

/** Upload-date windows offered by the browse filters. */
export type DateRangeKey = 'any' | 'week' | 'month' | 'year'
