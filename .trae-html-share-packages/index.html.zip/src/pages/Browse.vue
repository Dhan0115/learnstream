<script setup lang="ts">
import { computed, onMounted, ref, useId, watch } from 'vue'
import { useRoute } from 'vue-router'
import EmptyState from '@/components/EmptyState.vue'
import PageHeading from '@/components/PageHeading.vue'
import VideoCard from '@/components/VideoCard.vue'
import VideoSkeleton from '@/components/VideoSkeleton.vue'
import { useCatalog } from '@/composables/useCatalog'
import { messageFor } from '@/utils/api'
import type { DateRangeKey, SortKey, Video } from '@/types'

const PAGE_SIZE = 12

const route = useRoute()
const { subjects, fetchVideos, subjectBySlug } = useCatalog()

const subjectSelectId = useId()
const sortSelectId = useId()
const rangeSelectId = useId()

const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: 'newest', label: 'Newest' },
  { value: 'views', label: 'Most viewed' },
  { value: 'likes', label: 'Most liked' },
  { value: 'rated', label: 'Top rated' }
]

const RANGE_OPTIONS: { value: DateRangeKey; label: string }[] = [
  { value: 'any', label: 'Any time' },
  { value: 'week', label: 'Past week' },
  { value: 'month', label: 'Past month' },
  { value: 'year', label: 'Past year' }
]

function readSingle(value: unknown): string {
  return typeof value === 'string' ? value : ''
}

const subjectSlug = ref(readSingle(route.params.slug))
const searchTerm = ref(readSingle(route.query.q))
const sort = ref<SortKey>(
  SORT_OPTIONS.some(option => option.value === route.query.sort)
    ? (route.query.sort as SortKey)
    : 'newest'
)
const range = ref<DateRangeKey>(
  RANGE_OPTIONS.some(option => option.value === route.query.range)
    ? (route.query.range as DateRangeKey)
    : 'any'
)
const page = ref(1)

watch(
  () => [route.params.slug, route.query.q, route.query.sort, route.query.range],
  () => {
    subjectSlug.value = readSingle(route.params.slug)
    searchTerm.value = readSingle(route.query.q)
    sort.value = SORT_OPTIONS.some(option => option.value === route.query.sort)
      ? (route.query.sort as SortKey)
      : 'newest'
    range.value = RANGE_OPTIONS.some(option => option.value === route.query.range)
      ? (route.query.range as DateRangeKey)
      : 'any'
  }
)

const activeSubject = computed(() => subjectBySlug(subjectSlug.value))

// Search, filtering and ordering all happen on the server (design_spec.md §8.8),
// so the results below are exactly what the catalog holds right now.
const results = ref<Video[]>([])
const pending = ref(true)
const errorMessage = ref('')

async function load() {
  pending.value = true
  errorMessage.value = ''

  try {
    results.value = await fetchVideos({
      subjectSlug: subjectSlug.value || undefined,
      search: searchTerm.value,
      sort: sort.value,
      range: range.value
    })
  } catch (error) {
    results.value = []
    errorMessage.value = messageFor(error)
  } finally {
    pending.value = false
  }
}

onMounted(load)

// Any change to a filter re-queries the server. The route watcher above writes
// the same refs, so a link to `/search?q=…` loads the right list too.
watch([subjectSlug, searchTerm, sort, range], load)

const totalPages = computed(() => Math.max(1, Math.ceil(results.value.length / PAGE_SIZE)))
const visible = computed(() =>
  results.value.slice((page.value - 1) * PAGE_SIZE, page.value * PAGE_SIZE)
)

watch(results, () => {
  page.value = 1
})

watch([page, totalPages], () => {
  if (page.value > totalPages.value) page.value = totalPages.value
})

const heading = computed(() => {
  if (searchTerm.value) return `Results for “${searchTerm.value}”`
  if (activeSubject.value) return activeSubject.value.name
  return 'Browse all lessons'
})

const subtitle = computed(() => {
  if (searchTerm.value) return 'Matching lesson titles, descriptions, subjects and tags.'
  if (activeSubject.value) return activeSubject.value.tagline
  return 'Every published lesson, across all eight subjects.'
})

function goToPage(next: number) {
  page.value = Math.min(Math.max(1, next), totalPages.value)
  if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'smooth' })
}
</script>

<template>
  <div class="browse">
    <div class="browse__container">
      <PageHeading :title="heading" :subtitle="subtitle" :count="results.length" />

      <div class="browse__filters">
        <div class="browse__field">
          <label class="browse__label" :for="subjectSelectId">Subject</label>
          <select :id="subjectSelectId" v-model="subjectSlug" class="browse__select">
            <option value="">All subjects</option>
            <option v-for="subject in subjects" :key="subject.id" :value="subject.slug">
              {{ subject.name }}
            </option>
          </select>
        </div>

        <div class="browse__field">
          <label class="browse__label" :for="rangeSelectId">Uploaded</label>
          <select :id="rangeSelectId" v-model="range" class="browse__select">
            <option v-for="option in RANGE_OPTIONS" :key="option.value" :value="option.value">
              {{ option.label }}
            </option>
          </select>
        </div>

        <div class="browse__field">
          <label class="browse__label" :for="sortSelectId">Sort by</label>
          <select :id="sortSelectId" v-model="sort" class="browse__select">
            <option v-for="option in SORT_OPTIONS" :key="option.value" :value="option.value">
              {{ option.label }}
            </option>
          </select>
        </div>
      </div>

      <ul v-if="pending" class="browse__grid" aria-busy="true" aria-label="Loading lessons">
        <li v-for="n in 8" :key="n">
          <VideoSkeleton />
        </li>
      </ul>

      <ul v-else-if="visible.length" class="browse__grid">
        <li v-for="video in visible" :key="video.id">
          <VideoCard :video="video" />
        </li>
      </ul>

      <p v-else-if="errorMessage" class="browse__error" role="alert">{{ errorMessage }}</p>

      <EmptyState
        v-else
        :title="searchTerm ? 'No lessons matched your search' : 'No lessons here yet'"
        :text="searchTerm
          ? 'Try a different keyword, or browse a subject instead.'
          : 'No lesson matches these filters yet. Widen the upload date, or explore another subject.'"
        action-label="Browse all lessons"
        action-to="/browse"
      />

      <nav v-if="!pending && totalPages > 1" class="browse__pagination" aria-label="Pagination">
        <button
          type="button"
          class="browse__page-button"
          :disabled="page === 1"
          @click="goToPage(page - 1)"
        >
          Previous
        </button>
        <p class="browse__page-status">Page {{ page }} of {{ totalPages }}</p>
        <button
          type="button"
          class="browse__page-button"
          :disabled="page === totalPages"
          @click="goToPage(page + 1)"
        >
          Next
        </button>
      </nav>
    </div>
  </div>
</template>

<style scoped lang="scss">
@use '@/assets/scss/tokens' as *;
@use '@/assets/scss/mixins' as *;

.browse {
  &__container {
    width: 100%;
    max-width: 80rem;
    margin: 0 auto;
    padding: 2.5rem 1rem 0;

    @include up(sm) {
      padding-inline: 1.5rem;
    }

    @include up(lg) {
      padding-inline: 2rem;
    }

    @include up(md) {
      padding-top: 3.5rem;
    }
  }

  &__error {
    padding: 0.75rem 1rem;
    font-size: 0.875rem;
    font-weight: 600;
    color: $color-error;
    background: $color-surface-muted;
    border: 1px solid $color-error;
    border-radius: $radius-md;
  }

  &__filters {
    display: flex;
    flex-wrap: wrap;
    gap: 0.75rem;
    margin-bottom: 1.75rem;
    padding-bottom: 1.75rem;
    border-bottom: 1px solid $color-border;
  }

  &__field {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
    min-width: 11rem;
  }

  &__label {
    font-size: 0.75rem;
    font-weight: 600;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    color: $color-text-muted;
  }

  &__select {
    padding: 0.5rem 0.625rem;
    font-size: 0.875rem;
    color: $color-text;
    background: $color-surface;
    border: 1px solid $color-border;
    border-radius: $radius-md;
    cursor: pointer;

    @include focus-ring;
  }

  &__grid {
    display: grid;
    grid-template-columns: minmax(0, 1fr);
    gap: 1.5rem 1rem;
    list-style: none;

    @include up(sm) {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    @include up(lg) {
      grid-template-columns: repeat(3, minmax(0, 1fr));
    }

    @include up(xl) {
      grid-template-columns: repeat(4, minmax(0, 1fr));
    }
  }

  &__pagination {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1rem;
    margin-top: 2.5rem;
  }

  &__page-button {
    padding: 0.5rem 1rem;
    font-size: 0.875rem;
    font-weight: 600;
    color: $color-text;
    background: $color-surface;
    border: 1px solid $color-border;
    border-radius: $radius-md;
    cursor: pointer;
    transition: border-color 150ms ease;

    &:hover:not(:disabled) {
      border-color: $color-primary;
      color: $color-primary;
    }

    &:disabled {
      cursor: not-allowed;
      opacity: 0.5;
    }

    @include focus-ring;
  }

  &__page-status {
    font-size: 0.875rem;
    color: $color-text-muted;
  }
}
</style>
