<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import EmptyState from '@/components/EmptyState.vue'
import SearchBar from '@/components/SearchBar.vue'
import SectionHeader from '@/components/SectionHeader.vue'
import SubjectCard from '@/components/SubjectCard.vue'
import VideoCard from '@/components/VideoCard.vue'
import VideoSkeleton from '@/components/VideoSkeleton.vue'
import { useCatalog } from '@/composables/useCatalog'
import { useSession } from '@/composables/useSession'
import type { Video } from '@/types'

// `.home` page block (design_spec.md §4.1). The two rails are the catalog's
// "most viewed" and "newest" orderings, asked of the API rather than sorted
// from a private copy, so they always match what browse would show.
const { subjects, videoCount, fetchVideos } = useCatalog()
const { canUpload } = useSession()

const popularVideos = ref<Video[]>([])
const recentVideos = ref<Video[]>([])
const pending = ref(true)

const totalLessons = computed(() =>
  subjects.value.reduce((sum, subject) => sum + videoCount(subject.slug), 0)
)

onMounted(async () => {
  try {
    const [popular, recent] = await Promise.all([
      fetchVideos({ sort: 'views' }),
      fetchVideos({ sort: 'newest' })
    ])
    popularVideos.value = popular.slice(0, 6)
    recentVideos.value = recent.slice(0, 6)
  } catch {
    // Both rails fall back to their empty state.
  } finally {
    pending.value = false
  }
})
</script>

<template>
  <div class="home">
    <section class="home__hero">
      <div class="home__container">
        <p class="home__eyebrow">{{ totalLessons }} lessons across {{ subjects.length }} subjects</p>
        <h1 class="home__headline">
          Learn any subject through clear, engaging video lessons.
        </h1>
        <p class="home__subcopy">
          Discover lessons in maths, science, programming, history, languages and more —
          taught by people who love the subject.
        </p>

        <div class="home__ctas">
          <UButton to="/browse" size="lg" label="Browse Subjects" />
          <UButton to="/#featured" size="lg" variant="outline" color="neutral" label="Start Learning" />
          <UButton to="/upload" size="lg" variant="ghost" color="neutral" label="Upload a Video" />
        </div>

        <div class="home__search">
          <SearchBar />
        </div>
      </div>
    </section>

    <section id="subjects" class="home__section home__container">
      <SectionHeader
        title="Browse by subject"
        subtitle="Pick a subject to see every lesson in it."
        action-label="View all"
        action-to="/browse"
      />

      <ul class="home__subjects">
        <li v-for="subject in subjects" :key="subject.id">
          <SubjectCard :subject="subject" :count="videoCount(subject.slug)" />
        </li>
      </ul>
    </section>

    <section id="featured" class="home__section home__container">
      <SectionHeader
        title="Popular lessons"
        subtitle="The lessons learners return to most."
        action-label="See more"
        action-to="/browse?sort=views"
      />

      <ul v-if="pending" class="home__grid home__grid--videos" aria-busy="true" aria-label="Loading popular lessons">
        <li v-for="n in 6" :key="n">
          <VideoSkeleton />
        </li>
      </ul>

      <ul v-else class="home__grid home__grid--videos">
        <li v-for="(video, index) in popularVideos" :key="video.id">
          <VideoCard :video="video" :featured="index === 0" />
        </li>
      </ul>
    </section>

    <section id="recent" class="home__section home__container">
      <SectionHeader
        title="Recently uploaded"
        subtitle="Fresh lessons from our teachers."
        action-label="See more"
        action-to="/browse?sort=newest"
      />

      <ul v-if="pending" class="home__grid home__grid--recent" aria-busy="true" aria-label="Loading recent lessons">
        <li v-for="n in 6" :key="n">
          <VideoSkeleton />
        </li>
      </ul>

      <ul v-else-if="recentVideos.length" class="home__grid home__grid--recent">
        <li v-for="video in recentVideos" :key="video.id">
          <VideoCard :video="video" compact />
        </li>
      </ul>

      <EmptyState
        v-else
        icon="upload"
        title="No lessons yet"
        text="Be the first to publish a lesson — upload a video and it will appear here."
        action-label="Upload a Video"
        action-to="/upload"
      />
    </section>

    <section class="home__section home__container">
      <div class="home__band">
        <div class="home__band-text">
          <h2 class="home__band-title">Share what you know</h2>
          <p class="home__band-copy">
            Teachers and subject-matter experts can publish lessons in minutes: upload a video,
            describe what learners will gain, and tag it with a subject.
          </p>
        </div>
        <div class="home__band-actions">
          <UButton to="/upload" size="lg" label="Upload a Video" />
          <UButton
            v-if="!canUpload"
            to="/dashboard"
            size="lg"
            variant="outline"
            color="neutral"
            label="See your dashboard"
          />
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped lang="scss">
@use '@/assets/scss/tokens' as *;
@use '@/assets/scss/mixins' as *;

.home {
  &__container {
    width: 100%;
    max-width: 80rem;
    margin: 0 auto;
    padding-inline: 1rem;

    @include up(sm) {
      padding-inline: 1.5rem;
    }

    @include up(lg) {
      padding-inline: 2rem;
    }
  }

  &__hero {
    padding-block: 3rem 2.5rem;
    background: $color-surface-muted;
    border-bottom: 1px solid $color-border;

    @include up(md) {
      padding-block: 4.5rem 3.5rem;
    }
  }

  &__eyebrow {
    display: inline-block;
    margin-bottom: 1rem;
    padding: 0.25rem 0.625rem;
    font-size: 0.75rem;
    font-weight: 600;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    color: $color-primary;
    background: $color-surface;
    border: 1px solid $color-border;
    border-radius: 999px;
  }

  &__headline {
    max-width: 46rem;
    font-size: 1.875rem;
    font-weight: 800;
    line-height: 1.15;
    letter-spacing: -0.02em;
    color: $color-text-highlighted;

    @include up(md) {
      font-size: 2.75rem;
    }

    @include up(lg) {
      font-size: 3.25rem;
    }
  }

  &__subcopy {
    max-width: 40rem;
    margin-top: 1rem;
    font-size: 1rem;
    line-height: 1.65;
    color: $color-text-muted;

    @include up(md) {
      font-size: 1.125rem;
    }
  }

  &__ctas {
    display: flex;
    flex-wrap: wrap;
    gap: 0.625rem;
    margin-top: 1.75rem;
  }

  &__search {
    max-width: 40rem;
    margin-top: 1.75rem;
  }

  &__section {
    padding-block: 2.5rem;

    @include up(md) {
      padding-block: 4rem;
    }
  }

  &__subjects {
    display: grid;
    grid-template-columns: minmax(0, 1fr);
    gap: 1rem;
    list-style: none;

    @include up(sm) {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    @include up(lg) {
      grid-template-columns: repeat(4, minmax(0, 1fr));
    }
  }

  &__grid {
    display: grid;
    gap: 1.5rem 1rem;
    list-style: none;

    &--videos {
      grid-template-columns: minmax(0, 1fr);

      @include up(sm) {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }

      @include up(lg) {
        grid-template-columns: repeat(3, minmax(0, 1fr));
      }
    }

    &--recent {
      grid-template-columns: minmax(0, 1fr);

      @include up(md) {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }
    }
  }

  &__band {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
    padding: 1.75rem;
    background: $color-surface-muted;
    border: 1px solid $color-border;
    border-radius: $radius-xl;

    @include up(md) {
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      padding: 2.25rem 2.5rem;
    }
  }

  &__band-text {
    max-width: 42rem;
  }

  &__band-title {
    font-size: 1.375rem;
    font-weight: 700;
    line-height: 1.25;
    color: $color-text-highlighted;

    @include up(md) {
      font-size: 1.625rem;
    }
  }

  &__band-copy {
    margin-top: 0.5rem;
    font-size: 0.9375rem;
    line-height: 1.6;
    color: $color-text-muted;
  }

  &__band-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 0.625rem;
    flex: none;
  }
}
</style>
