<script setup lang="ts">
import AppFooter from '@/components/AppFooter.vue'
import AppHeader from '@/components/AppHeader.vue'
import { initTheme } from '@/composables/useTheme'

// Apply the stored/system theme before the first paint of the app tree.
initTheme()
</script>

<template>
  <UApp>
    <a class="skip-link" href="#main-content">Skip to main content</a>

    <AppHeader />

    <main id="main-content" class="app-main">
      <RouterView />
    </main>

    <AppFooter />
  </UApp>
</template>

<style scoped lang="scss">
@use '@/assets/scss/tokens' as *;
@use '@/assets/scss/mixins' as *;

.skip-link {
  position: absolute;
  left: 1rem;
  top: -3rem;
  z-index: 50;
  padding: 0.5rem 0.875rem;
  font-size: 0.875rem;
  font-weight: 600;
  color: var(--ui-bg);
  text-decoration: none;
  background: $color-primary;
  border-radius: $radius-md;
  transition: top 150ms ease;

  &:focus-visible {
    top: 1rem;
  }
}

.app-main {
  display: block;
  min-height: 60vh;
}
</style>
