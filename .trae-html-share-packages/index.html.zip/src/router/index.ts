import { createRouter, createWebHistory } from 'vue-router'
import { useSession } from '@/composables/useSession'

const { user } = useSession()

// Route table mirrors design_spec.md §2. Pages are lazy so each slice ships
// only the code its screens need.
export const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', name: 'home', component: () => import('@/pages/Home.vue') },
    { path: '/browse', name: 'browse', component: () => import('@/pages/Browse.vue') },
    { path: '/subjects/:slug', name: 'subject', component: () => import('@/pages/Browse.vue') },
    { path: '/search', name: 'search', component: () => import('@/pages/Browse.vue') },
    { path: '/watch/:id', name: 'watch', component: () => import('@/pages/Watch.vue') },
    { path: '/saved', name: 'saved', component: () => import('@/pages/Saved.vue'), meta: { requiresAuth: true } },
    { path: '/upload', name: 'upload', component: () => import('@/pages/Upload.vue'), meta: { requiresAuth: true } },
    { path: '/dashboard', name: 'dashboard', component: () => import('@/pages/Dashboard.vue'), meta: { requiresAuth: true } },
    { path: '/login', name: 'login', component: () => import('@/pages/Auth.vue') },
    { path: '/signup', name: 'signup', component: () => import('@/pages/Auth.vue') },
    { path: '/:pathMatch(.*)*', name: 'not-found', component: () => import('@/pages/NotFound.vue') }
  ],
  scrollBehavior(to, _from, savedPosition) {
    if (savedPosition) return savedPosition
    if (to.hash) return { el: to.hash, behavior: 'smooth' }
    return { top: 0 }
  }
})

// Saving, uploading and the dashboard belong to an account (design_spec.md §4.7).
// A visitor without one is sent to sign in, and lands where they were headed
// once they have an account.
router.beforeEach((to) => {
  if (!to.meta.requiresAuth || user.value) return true
  return { name: 'login', query: { redirect: to.fullPath } }
})
