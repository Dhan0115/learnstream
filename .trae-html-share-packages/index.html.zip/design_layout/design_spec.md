# LearnStream — Design Spec (Design of Record)

> **Status: APPROVED — design of record.** The owner approved this spec and the Slice 1 start.
> This file is the **design of record** referenced by
> [design_layout.md](./design_layout.md) §1: the single source of truth for structure, spacing,
> typography, colour, components, breakpoints and states.
>
> **Theme:** Nuxt UI (`@nuxt/ui` v4) — palettes from Nuxt UI only (`primary: indigo`,
> `secondary: teal`, `neutral: slate`). Every colour, radius and shadow comes from a
> Nuxt UI token. No custom palette, font or icon set is introduced.
>
> **Stack:** Vue 3 + Vite + TypeScript, `vue-router`, Tailwind 4, SCSS per [sass.md](./sass.md).
> **Naming:** BEM per [bem-convention.md](./bem-convention.md).

---

## 1. Design foundations

### 1.1 Colour

All colour is **Nuxt UI semantic tokens** — no hex values anywhere. Exact token availability is
confirmed against the installed `@nuxt/ui` version at the Step 1 gate.

| Role | Token | Used for |

|---|---|---|
| Primary | `var(--ui-primary)` | CTAs, active nav, links, focus ring, selected state |
| Secondary | `var(--ui-secondary)` | Accent highlights that must not compete with the primary CTA |
| Surface | `var(--ui-bg)` | Page and card background |
| Raised surface | `var(--ui-bg-elevated)` | Header on scroll, modals, dropdowns |
| Muted surface | `var(--ui-bg-muted)` | Section bands, inputs, skeleton placeholders |
| Text | `var(--ui-text)` | Body copy |
| Highlighted text | `var(--ui-text-highlighted)` | Headings |
| Muted text | `var(--ui-text-muted)` | Metadata, counts, helper text |
| Border | `var(--ui-border)` | Card edges, dividers, input outlines |
| Error | `var(--ui-error)` | Validation, destructive action |
| Success | `var(--ui-success)` | Upload success |
| Radius | `var(--ui-radius)` | Base corner radius, with Tailwind `rounded-*` steps |

### 1.2 Typography

Tailwind's default scale and the Nuxt UI font stack — **no new family, no new scale.**

| Element | Utilities | Notes |

|---|---|---|
| Hero headline | `text-3xl md:text-4xl font-bold` | `--ui-text-highlighted` |
| Page title | `text-2xl md:text-3xl font-bold` | Page block `__title` |
| Section heading | `text-xl md:text-2xl font-semibold` | `.section-header__title` |
| Card title | `text-base font-semibold` | `.video-card__title`, `.subject-card__title` |
| Body | `text-base` / `text-sm` | `--ui-text` |
| Meta | `text-sm` | `--ui-text-muted` |
| Badge / label | `text-xs uppercase tracking-wide` | `.video-card__badge` |

Line height stays Tailwind default (`leading-tight` for headings, `leading-relaxed` for descriptions).

### 1.3 Spacing, radius, elevation

- **Spacing:** Tailwind scale only (`p-4`, `gap-6`, `space-y-10`). No ad-hoc pixel values.
- **Vertical rhythm:** page sections `py-10 md:py-16`; card padding `p-3 md:p-4`.
- **Radius:** `rounded-md` controls, `rounded-lg` cards, `rounded-xl` hero/media surfaces.
- **Elevation:** borders first (`border border-[var(--ui-border)]`); shadow only on
  `--scrolled` header, dropdowns and modals — Nuxt UI defaults.
- **Container:** `mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8`.

### 1.4 Breakpoints (mobile-first)

Tailwind defaults: `sm 640` · `md 768` · `lg 1024` · `xl 1280` · `2xl 1536`.
Written with the `up()` mixin in Sass and `sm:`/`md:`/`lg:` utilities in templates.

### 1.5 Motion

`transition-colors duration-150` / `transition-transform duration-150` for hover and focus only.
No entrance animations, no gradients, no decorative motion. `prefers-reduced-motion` disables transitions.

---

## 2. Information architecture

| Route | Page block | Purpose |

|---|---|---|
| `/` | `.home` | Discover: hero, search, subjects, featured, recent, CTAs |
| `/browse` | `.browse` | All subjects grid |
| `/subjects/:slug` | `.browse` | One subject's lesson list |
| `/search?q=` | `.browse` | Search results across title/subject/tags/description |
| `/watch/:id` | `.watch` | Player + metadata + actions + related + comments |
| `/saved` · **account** | `.saved` | A learner's saved lessons, with the date each was saved |
| `/upload` · **account** | `.upload` | Guided upload flow (educator roles only) |
| `/dashboard` · **account** | `.dashboard` | Uploader stats, own videos, drafts |
| `/login` | `.auth` | Sign in to an account held in this browser |
| `/signup` | `.auth` | Create an account held in this browser |
| `/404` (catch-all) | `.empty-state` | Friendly not-found page |

**account** routes are guarded (`meta.requiresAuth`): a visitor without a session is sent to
`/login?redirect=…` and returned to the page they asked for once they have an account. Watching,
browsing and searching stay open to everyone.

---

## 3. Global shell

### 3.1 `.app-header`

| Element | Content |

|---|---|
| `__logo` | Wordmark "LearnStream", links to `/` |
| `__nav` | Browse · Subjects · Saved, plus Dashboard for educator accounts |
| `__search` | `.search-bar --compact`, hidden below `md` (moves into `--menu-open` panel) |
| `__account` | Signed in: `__avatar` + `__name` + `__signout`, and `__upload` for educators. Signed out: `__signin` and `__signup`. |

Modifiers: `--scrolled` (raised surface + border), `--menu-open` (mobile panel).
`__menu-toggle` is visible below `md` only. Sticky top, `z-40`.
`__signin`, `__signup` and `__signout` live in the mobile panel below `sm`.

### 3.2 `.app-footer`

`__brand`, `__columns` (Learn · Subjects · About), `__meta` (copyright, `--ui-text-muted`).
Regions are semantic `<header>` / `<nav>` / `<main>` / `<footer>` landmarks.

---

## 4. Page specifications

### 4.1 `.home`

| Order | Region | Contents |

|---|---|---|
| 1 | `__hero` | Headline "Learn any subject through clear, engaging video lessons.", one-line subcopy, CTA row: **Browse Subjects** (solid), **Start Learning** (outline), **Upload a Video** (ghost → gated) |
| 2 | `__search` | Full-width `.search-bar` with placeholder "Search videos, subjects, topics…" |
| 3 | `__subjects` | `.section-header` + grid of `.subject-card`: Mathematics, Science, Programming, History, Languages, Business, Art, Test Preparation |
| 4 | `__featured` | `.section-header` ("Popular Lessons") + grid of `.video-card` |
| 5 | `__recent` | `.section-header` ("Recently Uploaded") + grid of `.video-card --compact` |
| 6 | `__cta` | Teacher band: "Share what you know" + **Upload a Video** |

Grid: 1 col → `sm:2` → `lg:4` for subjects; 1 → `sm:2` → `lg:3` for videos.

### 4.2 `.browse`

`__heading` (subject name or "Results for “q”"), `__filters` — **Subject**, **Uploaded**
(Any time · Past week · Past month · Past year) and **Sort by** (Newest · Most viewed · Most liked ·
Top rated) — `__grid` of `.video-card`, `__count`. Filters combine: subject ∩ upload date ∩ search.
Empty result → `.empty-state`. Pagination: `__pagination` (12 per page). The grid shows
`.video-skeleton` placeholders while results resolve.

**Top rated** ranks by like share (likes ÷ all votes), then by like count, so a lesson with a single
vote cannot outrank a strongly rated one with many.

### 4.3 `.watch`

| Region | Contents |

|---|---|
| `__player` | `.video-player` — play/pause, volume/mute, fullscreen, speed (0.5×–2×), seek bar, captions toggle |
| `__title` | Video title |
| `__channel` | Uploader name + avatar + subscribe-style follow button |
| `__actions` | `.watch__action` buttons: Like (`count`), Dislike (`count`), Save (toggles), Share |
| `__description` | Expandable (`is-expanded`), shows what the viewer will learn |
| `__tags` | `.tag-list` — subject badge + keyword tags |
| `__meta` | View count · published date · duration |
| `__related` | "More videos in this subject" — `.video-card --compact` list |
| `__comments` | `.comment-section` — list + form; `--empty` when none |

Layout: single column below `lg`; player full width; `lg` → player + related in a 2/3 + 1/3 grid.

View counting: opening a lesson counts one view, recorded in `learnstream:views`. A repeat view of
the same lesson inside a 30-minute window — a refresh, a back-and-forth, or a second tab — is
ignored, so rapid reloads cannot inflate `__meta`.

Actions: Like, Dislike and Save belong to an account. For a signed-out visitor the click is a
sign-in prompt — the router sends them to `/login?redirect=/watch/:id` and returns them here — and
one account holds at most one reaction per lesson (`learnstream:reactions`).

### 4.4 `.upload` (gated: `role === 'teacher' || 'admin'`)

| Step | Element | Requirements |
|---|---|---|
| 1 | `__dropzone` (`.dropzone`) | Drag-and-drop or browse; accepts MP4/WebM; rejects others with `has-error` + message |
| 2 | `__progress` | `.upload__progress` bar + percentage during upload |
| 3 | `__fields` | **Title** (required), **Description** (required), Subject (optional select), Tags (optional), Thumbnail (optional) |
| 4 | `__preview` | Preview panel: thumbnail, title, description, subject, tags |
| 5 | `__status` | `is-uploading` / `is-success` / `has-error` messages |

Auto-thumbnail: if no image is provided, generate a 16:9 poster from the video's first frame.
An account without an educator role sees `.empty-state` explaining the requirement; a visitor
without a session is sent to sign in before the page renders.

### 4.5 `.dashboard`

`__profile` (avatar, name, role, saved-count link, Upload CTA when the role allows), `__stats`
(lessons, total views, total likes, total dislikes, total saves), `__tabs` (My Videos · Drafts),
`__videos` (`.video-card` grid with status badge), `__empty`. Published uploads appear here and in
search/browse immediately. Saves are a per-browser figure — they count how many of the uploader's
lessons are on this device's saved list. A learner's saved lessons live on `.saved` (§4.6).

### 4.6 `.saved`

`__heading` (`.page-heading`, "Saved videos" + lesson count), `__grid` of `.video-card` — thumbnail,
title, subject badge, and a `__note` line reading "Saved {relative date}" — and `.empty-state` when
nothing is saved. `.video-skeleton` placeholders cover the grid while it resolves. Saving is stored
in this browser (`learnstream:saved`), so the page states that plainly. The route is guarded, so a
visitor without a session signs in first.

### 4.7 `.auth` (serves `/login` and `/signup`)

One narrow centered card, `max-width: 26rem`. Regions:

| Element | Contents |

|---|---|
| `__title` | "Welcome back" or "Create your account" |
| `__subtitle` | One line on what an account is for |
| `__error` | `role="alert"` message from `useSession`, shown above the form |
| `__form` | `__field` (label + input) for **Email** + **Password**, plus **Display name** on sign-up |
| `__roles` | Sign-up only: a `fieldset`/`legend` of two `__role` radio rows — Learner · Educator |
| `__submit` | `UButton size="lg"`, full width, `:loading` while the hash is computed |
| `__switch` | Link across to the other route (`/login` ⇄ `/signup`) |
| `__note` | Plain statement that accounts are a demo, stored locally, with the password hashed |

After success the visitor lands on `redirect` (the guarded page they asked for) or `/dashboard`.
No password is ever stored, echoed or logged; validation errors come from `useSession` so the page
and the composable cannot disagree.

---

## 5. Component inventory (BEM blocks)

Existing blocks from [bem-convention.md](./bem-convention.md) §4 are **reused**; new blocks follow the same rules.

| Block | Elements | Modifiers / state |

|---|---|---|
| `.app-header` | `__logo` `__nav` `__search` `__account` `__upload` `__identity` `__avatar` `__name` `__signin` `__signup` `__signout` `__menu-toggle` | `--scrolled` `--menu-open` |
| `.app-footer` | `__brand` `__columns` `__meta` | — |
| `.skip-link` | — | — |
| `.icon` | — | — |
| `.search-bar` | `__input` `__icon` `__submit` | `--compact` `has-error` |
| `.subject-card` | `__icon` `__title` `__tagline` `__count` | `--active` |
| `.video-card` | `__thumb` `__thumb-fallback` `__body` `__title` `__meta` `__badge` `__note` `__status` | `--featured` `--compact` |
| `.video-skeleton` | `__thumb` `__line` | `__line--short` |
| `.video-player` | `__stage` `__controls` `__seek` `__caption` `__poster-fallback` | `--fullscreen` `--muted` `is-playing` |
| `.comment-section` | `__list` `__item` `__form` `__signin` | `--empty` |
| `.section-header` | `__title` `__action` | — |
| `.tag-list` | `__item` | — |
| `.empty-state` | `__icon` `__title` `__text` `__action` | — |
| `.dropzone` | `__input` `__hint` `__preview` `__clear` | `is-dragging` `has-error` `--compact` |
| `.progress-bar` | `__track` `__fill` `__value` | `--success` `--error` |
| `.stat-tile` | `__value` `__label` `__icon` | — |
| `.page-heading` | `__title` `__subtitle` `__count` | — |
| `.auth` | `__card` `__title` `__subtitle` `__error` `__form` `__field` `__label` `__input` `__hint` `__roles` `__legend` `__role` `__role-text` `__role-label` `__role-hint` `__radio` `__submit` `__switch` `__switch-link` `__note` | `__role--active` |

Every block ships with default, hover, `focus-visible`, disabled and loading/empty states.

---

## 6. Accessibility

- Semantic landmarks; one `<h1>` per page; ordered heading levels; skip-to-content link.
- All images have `alt`; decorative icons `aria-hidden`.
- Player: keyboard-operable controls, visible focus ring (`--ui-primary`), captions toggle,
  transcript panel below the player.
- Icon-only buttons have `aria-label`.
- Contrast meets WCAG AA via Nuxt UI tokens; state is never colour-only (icon + text).
- Touch targets ≥ 44px on mobile; forms have real `<label>`s and inline error text with `aria-describedby`.
- Respect `prefers-reduced-motion`.
- Lesson grids render `.video-skeleton` placeholders inside a list marked `aria-busy` with a label;
  the skeleton itself is `aria-hidden`, and its pulse stops under `prefers-reduced-motion`.

---

## 7. Data model (mock, localStorage)

Typed seed data in `src/data/`, persisted client-side. No backend, no secrets, nothing irreversible.

| Entity | Fields |

|---|---|
| `User` | `id, name, email, initials, role: 'learner' \| 'teacher' \| 'admin'` — `learner` is the viewer; `teacher` and `admin` may publish |
| `Subject` | `id, slug, name, icon, tagline` — `videoCount` is **derived** from the catalog, never stored |
| `Video` | `id, title, description, subjectSlug, tags[], uploaderId, uploaderName, src, thumbnail, durationSec, views, likes, dislikes, createdAt, status: 'published' \| 'processing'` |
| `Comment` | `id, videoId, authorName, body, createdAt` |
| `SavedEntry` | `videoId, savedAt` — one per saved lesson; the list is kept newest first |
| `Account` | The `User` fields plus `salt, passwordHash` — the stored form of an account |

Storage keys: `learnstream:accounts`, `learnstream:session`, `learnstream:videos`, `learnstream:saved`,
`learnstream:reactions`, `learnstream:comments`, `learnstream:views`.

The session is `learnstream:session` — the id of the signed-in account, so a reload keeps it.
`learnstream:accounts` holds every account created in this browser. A password is written only as a
random per-account salt plus the SHA-256 digest derived from it, so nothing in storage can be
replayed as a password (§8.10).

---

## 8. Decisions (confirmed)

1. **Video sources.** Confirmed: **placeholder + poster.** Seeded lessons carry an empty placeholder
   `src` and render the generated 16:9 poster; the player shows an explicit "demo lesson" state.
   No sample MP4s are added to the repo.
2. **Primary hue.** Confirmed (**changed by owner, 2026-11-18**): Nuxt UI `primary: 'indigo'` with
   `secondary: 'teal'` and `slate` neutrals, set through the `ui()` plugin in `vite.config.ts`
   (`ui({ ui: { colors: { primary: 'indigo', secondary: 'teal', neutral: 'slate' } } })`).
   The hues are still Nuxt UI palettes — no custom palette, hex value or CSS override is added.
3. **Site name** "LearnStream" (from `package.json`).
4. **Dark mode.** Confirmed: **included** as a header toggle, persisted to `localStorage`.
5. **Container width** `max-w-7xl` (equivalent to Nuxt UI's `--ui-container: 80rem`).
6. **Comments** are stored locally per browser (no shared persistence) — acceptable for the mock.
7. **Subject icons.** Subject tiles use a **monogram** tile (the subject's initial) instead of an
   SVG icon set, so the app depends on no icon collection. Recorded as `.subject-card__icon`.
8. **Iconography.** A single dependency-free `.icon` block renders every inline SVG the UI needs —
   search, menu, close, sun, moon, play, pause, volume, maximize, chevrons, clock, eye, upload, user,
   check, alert, bookmark, heart, thumbs-down, share, lock, sparkles, composite, mic and captions.
   No iconify collection is added. Sign in / sign up are worded buttons, not icons.
9. **Catalog persistence.** Slice 1 keeps the seeded catalog in memory; `localStorage` persistence
   is introduced with the upload flow (Slice 4) so re-seeding can never serve stale data.
10. **Accounts.** Confirmed (**owner, 2026-11-18**): **sign-in is required** for `/saved`, `/upload`
    and `/dashboard`; browsing, searching and watching stay open. Accounts are created through
    `/signup` and kept in this browser, and the session is the account id in `learnstream:session`.
    The header role switcher is gone — a role now comes from the account: `learner` watches and
    saves, `teacher` and `admin` also publish.
11. **Password handling.** A password is never stored, echoed, prefilled or logged. Each account
    gets 128 bits of random salt and only `salt` + `passwordHash` (SHA-256) reach `localStorage`,
    so storage holds nothing replayable. This is honest only as a demo — there is no server, so it
    is not real authentication, and `.auth__note` says exactly that. `crypto.subtle` needs a secure
    context (https or localhost); elsewhere sign-up reports that instead of failing silently.

---

## 9. Build slices (after approval)

1. **Slice 1 — foundations + shell + Home.** `src/assets/scss/` layer, `@` Vite alias, `.app-header`,
   `.app-footer`, `/` with all six regions, mock data layer, generated image assets.
2. **Slice 2 — discovery.** `/browse`, `/subjects/:slug`, `/search`, `.subject-card` + `.video-card` states.
3. **Slice 3 — watch.** `/watch/:id`, `.video-player`, actions, related, `.comment-section`, transcript.
4. **Slice 4 — upload + dashboard.** `.dropzone`, progress, preview, validation, `/dashboard`, gating.
5. **Slice 5 — engagement + accounts.** Palette and view counting, Top rated / upload-date filters,
   `.video-skeleton` loaders, `/saved`, `.auth` sign-up and sign-in with guarded routes (§4.7).

Each slice runs the [Skill.md](./Skill.md) §3 verification (per-step + per-rulebook + cross-artifact)
and reports its gates before the next begins.
